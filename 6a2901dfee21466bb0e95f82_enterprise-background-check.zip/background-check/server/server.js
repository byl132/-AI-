/**
 * 企业背查小程序 - 后端API服务
 * 使用原生 Node.js http 模块，端口 3000
 * Railway 部署时同时托管静态文件
 */

const http = require('http');
const url = require('url');
const fs = require('fs');
const path = require('path');

// 静态文件目录（项目根目录）
const STATIC_DIR = path.resolve(__dirname, '..');

// MIME 类型映射
const MIME_TYPES = {
  '.html': 'text/html; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.js': 'application/javascript; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.gif': 'image/gif',
  '.svg': 'image/svg+xml',
  '.ico': 'image/x-icon',
  '.woff': 'font/woff',
  '.woff2': 'font/woff2',
  '.ttf': 'font/ttf'
};

/**
 * 处理静态文件请求（同步版本，用于 Railway 部署）
 */
function serveStaticFile(res, filePath) {
  const safePath = path.normalize(filePath).replace(/^(\.\.[\/\\])+/, '');
  const fullPath = path.join(STATIC_DIR, safePath);

  // 防止目录遍历攻击
  if (!fullPath.startsWith(STATIC_DIR)) {
    res.writeHead(403);
    res.end('Forbidden');
    return true;
  }

  try {
    if (!fs.existsSync(fullPath) || !fs.statSync(fullPath).isFile()) {
      return false;
    }

    const ext = path.extname(fullPath).toLowerCase();
    const contentType = MIME_TYPES[ext] || 'application/octet-stream';
    const data = fs.readFileSync(fullPath);
    res.writeHead(200, { 'Content-Type': contentType });
    res.end(data);
    return true;
  } catch (e) {
    return false;
  }
}

// ============================================================
// 公司完整数据（内置5家公司）
// ============================================================

const companyDB = {
  '字节跳动': {
    company: {
      name: '字节跳动',
      fullName: '北京字节跳动科技有限公司',
      industry: '互联网/科技',
      founded: '2012年',
      location: '北京市海淀区',
      scale: '10000人以上',
      logo: 'https://img.icons8.com/color/200/tiktok--v1.png',
      description: '字节跳动是一家全球化的科技公司，旗下拥有抖音、今日头条、TikTok等多款知名产品，业务覆盖短视频、资讯、教育、游戏等多个领域。',
      tags: ['互联网', '短视频', '全球化', 'AI驱动'],
      website: 'https://www.bytedance.com',
      status: '在营',
      registeredCapital: '30000万美元',
      legalPerson: '张利东',
      socialCreditCode: '91110108MA00BKXN9D',
      employees: '约150000人'
    },
    annualReport: {
      name: '字节跳动',
      years: ['2021', '2022', '2023', '2024'],
      revenue: [580, 850, 1200, 1600],
      revenueUnit: '亿美元',
      revenueGrowth: [70, 47, 41, 33],
      netProfit: [80, 150, 250, 350],
      netProfitUnit: '亿美元',
      netProfitGrowth: [60, 88, 67, 40],
      employeeCount: [110000, 130000, 140000, 150000],
      rdInvestment: [180, 280, 400, 520],
      rdInvestmentUnit: '亿美元',
      rdRatio: [31, 33, 33, 33],
      highlights: [
        '2024年TikTok全球月活突破15亿',
        '抖音电商GMV突破2万亿人民币',
        'AI大模型"豆包"用户突破1亿',
        '海外业务收入占比超过50%'
      ]
    },
    laborArbitration: {
      name: '字节跳动',
      totalCases: 186,
      trend: [28, 35, 42, 48, 33],
      trendYears: ['2020', '2021', '2022', '2023', '2024'],
      categories: [
        { type: '违法解除劳动合同', count: 52, percentage: 28 },
        { type: '加班费争议', count: 45, percentage: 24 },
        { type: '竞业限制纠纷', count: 38, percentage: 20 },
        { type: '年终奖争议', count: 28, percentage: 15 },
        { type: '工伤赔偿', count: 15, percentage: 8 },
        { type: '其他', count: 8, percentage: 5 }
      ],
      winRate: { employee: 42, company: 58 },
      riskLevel: '中等',
      typicalCases: [
        { title: '员工诉字节跳动违法解除劳动合同', year: 2024, result: '员工胜诉，赔偿32万元' },
        { title: '前员工竞业限制违约纠纷', year: 2023, result: '公司胜诉，违约金120万元' },
        { title: '加班费集体仲裁案', year: 2023, result: '调解结案，公司补发加班费' }
      ]
    },
    judicial: {
      name: '字节跳动',
      totalCases: 342,
      asPlaintiff: 198,
      asDefendant: 144,
      trend: [45, 58, 72, 85, 82],
      trendYears: ['2020', '2021', '2022', '2023', '2024'],
      categories: [
        { type: '著作权侵权', count: 86, percentage: 25 },
        { type: '不正当竞争', count: 68, percentage: 20 },
        { type: '劳动争议', count: 52, percentage: 15 },
        { type: '合同纠纷', count: 45, percentage: 13 },
        { type: '名誉权纠纷', count: 38, percentage: 11 },
        { type: '商标侵权', count: 32, percentage: 9 },
        { type: '其他', count: 21, percentage: 7 }
      ],
      recentCases: [
        { title: '字节跳动诉某公司不正当竞争', year: 2024, result: '胜诉，赔偿500万元' },
        { title: '某公司诉字节跳动著作权侵权', year: 2024, result: '败诉，赔偿200万元' },
        { title: '字节跳动诉前员工商业秘密泄露', year: 2023, result: '胜诉，获赔800万元' }
      ]
    },
    overtimeReview: {
      name: '字节跳动',
      avgWorkHours: 10.5,
      overtimeFrequency: '频繁',
      overtimeRating: 2.3,
      overtimeRatingDesc: '加班较严重',
      employeeReviews: {
        totalCount: 12580,
        positiveRate: 35,
        neutralRate: 25,
        negativeRate: 40,
        overallRating: 3.2,
        dimensions: {
          '薪资福利': 4.0,
          '工作生活平衡': 2.1,
          '职业发展': 3.8,
          '公司文化': 3.0,
          '管理层': 3.2,
          '工作环境': 3.5
        },
        hotComments: [
          { content: '薪资确实给得高，但加班太多了，基本没有个人时间。大小周制度让人身心俱疲。', sentiment: 'negative', likes: 2356 },
          { content: '技术氛围很好，能接触到最前沿的技术，成长很快。但代价是牺牲生活。', sentiment: 'neutral', likes: 1892 },
          { content: '福利待遇在互联网行业算顶尖的，免费三餐下午茶，年终奖也比较丰厚。', sentiment: 'positive', likes: 1654 },
          { content: '领导层变动频繁，组织架构调整太频繁，让人没有安全感。', sentiment: 'negative', likes: 1432 },
          { content: '平台大、资源多，做出来的产品影响力大，成就感强。', sentiment: 'positive', likes: 1287 }
        ]
      }
    },
    bossActivity: {
      name: '字节跳动',
      totalPositions: 3856,
      activePositions: 2156,
      avgResponseTime: '2小时内',
      responseRate: 78,
      monthlyTrend: [320, 380, 420, 450, 486],
      monthlyTrendMonths: ['1月', '2月', '3月', '4月', '5月'],
      hotPositions: [
        { title: '高级算法工程师', salary: '50-80K', count: 186 },
        { title: '产品经理', salary: '30-50K', count: 145 },
        { title: '前端开发工程师', salary: '35-60K', count: 132 },
        { title: '后端开发工程师', salary: '35-65K', count: 128 },
        { title: '数据分析师', salary: '25-45K', count: 96 }
      ],
      activityIndex: 85
    },
    jobAdvice: {
      name: '字节跳动',
      overallScore: 72,
      recommendation: '谨慎考虑',
      pros: [
        '薪资水平行业领先，现金+期权组合有吸引力',
        '技术栈先进，个人技术成长快',
        '平台大，项目影响力强，简历加分',
        '福利待遇完善，免费三餐+健身房+体检'
      ],
      cons: [
        '加班文化严重，大小周制度普遍',
        '组织架构调整频繁，稳定性差',
        '内部竞争激烈，压力较大',
        '裁员风险存在，需关注业务线健康度'
      ],
      salaryRange: '25K-80K',
      interviewDifficulty: '较难',
      interviewTips: [
        '重点准备算法和数据结构',
        '了解字节跳动产品矩阵和最新动态',
        '准备好项目深度复盘',
        '关注AI/大模型相关技术方向'
      ],
      careerDevelopment: '技术路线和管理路线双通道，晋升机会多但竞争激烈'
    },
    investment: {
      name: '字节跳动',
      totalInvestment: '约350亿美元',
      investors: [
        { name: '红杉资本', round: '多轮', amount: '未公开' },
        { name: '软银愿景基金', round: 'E轮', amount: '30亿美元' },
        { name: '泛大西洋投资', round: 'E轮', amount: '20亿美元' },
        { name: '海纳亚洲', round: 'C轮', amount: '10亿美元' }
      ],
      valuation: '约3000亿美元',
      latestRound: '未公开（非上市公司）',
      fundingHistory: [
        { round: '天使轮', year: 2012, amount: '数百万人民币' },
        { round: 'A轮', year: 2013, amount: '1000万美元' },
        { round: 'B轮', year: 2014, amount: '1亿美元' },
        { round: 'C轮', year: 2016, amount: '10亿美元' },
        { round: 'D轮', year: 2017, amount: '20亿美元' },
        { round: 'E轮', year: 2020, amount: '50亿美元' }
      ],
      ipoStatus: '暂无明确上市计划',
      investmentScore: 88
    },
    socialSecurity: {
      name: '字节跳动',
      complianceRate: 96,
      baseRatio: '全额缴纳',
      housingFundRate: '12%',
      averageBase: '25000元',
      months: ['2024-01', '2024-02', '2024-03', '2024-04', '2024-05', '2024-06'],
      paymentRecords: [96, 97, 96, 97, 96, 97],
      issues: [
        { month: '2023-06', issue: '部分外包员工社保基数不足', status: '已整改' }
      ],
      overallRating: '优秀',
      riskLevel: '低'
    },
    stock: {
      name: '字节跳动',
      isListed: false,
      stockCode: null,
      stockPrice: null,
      ipoPlan: '暂无明确上市计划',
      ipoRumor: '市场多次传闻将在港股或美股上市，但公司官方未确认',
      preIpoValuation: '约3000亿美元',
      investmentHighlights: [
        '全球最大的短视频平台运营商',
        'TikTok海外用户超过15亿',
        'AI大模型"豆包"快速崛起',
        '多元化业务布局降低风险'
      ],
      investmentRisks: [
        '中美关系紧张影响TikTok在美运营',
        '非上市公司流动性差',
        '监管政策不确定性',
        '估值较高，增长放缓'
      ]
    },
    culture: {
      name: '字节跳动',
      overallScore: 65,
      workStyle: '高效务实，数据驱动',
      workStyleRating: 3.5,
      values: [
        { name: '追求极致', score: 4.2 },
        { name: '开放谦逊', score: 3.0 },
        { name: '务实敢为', score: 3.8 },
        { name: '多元兼容', score: 3.2 },
        { name: '坦诚清晰', score: 2.8 },
        { name: '始终创业', score: 3.5 }
      ],
      perks: [
        '免费三餐+下午茶+零食',
        '弹性工作制（10-7-5工作制）',
        '年度免费高端体检',
        '健身房+游泳池',
        '租房补贴',
        '期权激励计划'
      ],
      painPoints: [
        '大小周制度（隔周双休）',
        '加班文化普遍，10点后下班常见',
        '组织架构频繁调整',
        '内部OKR压力大',
        '末位淘汰机制'
      ],
      wlbScore: 2.1,
      wlbDesc: '工作生活平衡较差',
      employeeSatisfaction: 62,
      turnoverRate: 18
    }
  },

  '腾讯': {
    company: {
      name: '腾讯',
      fullName: '深圳市腾讯计算机系统有限公司',
      industry: '互联网/科技',
      founded: '1998年',
      location: '深圳市南山区',
      scale: '10000人以上',
      logo: 'https://img.icons8.com/color/200/tencent-qq--v1.png',
      description: '腾讯是中国最大的互联网综合服务提供商之一，旗下拥有微信、QQ、腾讯游戏、腾讯云等核心业务，在社交、游戏、支付等领域占据重要地位。',
      tags: ['互联网', '社交', '游戏', '金融科技'],
      website: 'https://www.tencent.com',
      status: '在营',
      registeredCapital: '6500万美元',
      legalPerson: '马化腾',
      socialCreditCode: '9144030071526726XG',
      employees: '约105000人'
    },
    annualReport: {
      name: '腾讯',
      years: ['2021', '2022', '2023', '2024'],
      revenue: [5601, 5546, 6090, 6600],
      revenueUnit: '亿人民币',
      revenueGrowth: [9, -1, 10, 8],
      netProfit: [1248, 1156, 1577, 1800],
      netProfitUnit: '亿人民币',
      netProfitGrowth: [1, -7, 36, 14],
      employeeCount: [112000, 108000, 105000, 105000],
      rdInvestment: [518, 614, 640, 700],
      rdInvestmentUnit: '亿人民币',
      rdRatio: [9.2, 11.1, 10.5, 10.6],
      highlights: [
        '微信月活突破13.4亿',
        '游戏业务全球收入排名第一',
        '腾讯云市场份额持续增长',
        '视频号商业化收入大幅增长'
      ]
    },
    laborArbitration: {
      name: '腾讯',
      totalCases: 98,
      trend: [15, 18, 22, 25, 18],
      trendYears: ['2020', '2021', '2022', '2023', '2024'],
      categories: [
        { type: '违法解除劳动合同', count: 25, percentage: 26 },
        { type: '竞业限制纠纷', count: 22, percentage: 22 },
        { type: '年终奖争议', count: 18, percentage: 18 },
        { type: '加班费争议', count: 15, percentage: 15 },
        { type: '工伤赔偿', count: 10, percentage: 10 },
        { type: '其他', count: 8, percentage: 9 }
      ],
      winRate: { employee: 38, company: 62 },
      riskLevel: '较低',
      typicalCases: [
        { title: '员工诉腾讯违法解除劳动合同', year: 2024, result: '调解结案，赔偿18万元' },
        { title: '前员工竞业限制违约纠纷', year: 2023, result: '公司胜诉，违约金80万元' },
        { title: '年终奖发放争议', year: 2023, result: '员工胜诉，补发年终奖12万元' }
      ]
    },
    judicial: {
      name: '腾讯',
      totalCases: 456,
      asPlaintiff: 268,
      asDefendant: 188,
      trend: [62, 75, 88, 95, 136],
      trendYears: ['2020', '2021', '2022', '2023', '2024'],
      categories: [
        { type: '著作权侵权', count: 105, percentage: 23 },
        { type: '不正当竞争', count: 82, percentage: 18 },
        { type: '商标侵权', count: 65, percentage: 14 },
        { type: '合同纠纷', count: 58, percentage: 13 },
        { type: '劳动争议', count: 45, percentage: 10 },
        { type: '名誉权纠纷', count: 52, percentage: 11 },
        { type: '其他', count: 49, percentage: 11 }
      ],
      recentCases: [
        { title: '腾讯诉某公司侵犯游戏著作权', year: 2024, result: '胜诉，赔偿2000万元' },
        { title: '某公司诉腾讯垄断', year: 2024, result: '部分胜诉' },
        { title: '腾讯诉某平台不正当竞争', year: 2023, result: '胜诉，赔偿800万元' }
      ]
    },
    overtimeReview: {
      name: '腾讯',
      avgWorkHours: 9.5,
      overtimeFrequency: '较多',
      overtimeRating: 3.0,
      overtimeRatingDesc: '加班中等偏多',
      employeeReviews: {
        totalCount: 18920,
        positiveRate: 48,
        neutralRate: 28,
        negativeRate: 24,
        overallRating: 3.8,
        dimensions: {
          '薪资福利': 4.5,
          '工作生活平衡': 3.0,
          '职业发展': 3.8,
          '公司文化': 3.5,
          '管理层': 3.6,
          '工作环境': 4.2
        },
        hotComments: [
          { content: '鹅厂福利是真的好，六险一金全额缴纳，年终奖也很给力。就是加班还是不少。', sentiment: 'neutral', likes: 3562 },
          { content: '在腾讯工作五年了，技术成长很多，团队氛围好。最近开始推行不加班文化，有改善。', sentiment: 'positive', likes: 2890 },
          { content: '薪资确实高，但大厂病也明显，流程复杂，跨部门沟通成本高。', sentiment: 'neutral', likes: 2345 },
          { content: '游戏部门加班严重，其他部门相对好一些。看具体团队。', sentiment: 'neutral', likes: 1987 },
          { content: '公司稳定，福利好，适合长期发展。推荐应届生来。', sentiment: 'positive', likes: 1765 }
        ]
      }
    },
    bossActivity: {
      name: '腾讯',
      totalPositions: 4256,
      activePositions: 2856,
      avgResponseTime: '1天内',
      responseRate: 72,
      monthlyTrend: [420, 480, 520, 560, 676],
      monthlyTrendMonths: ['1月', '2月', '3月', '4月', '5月'],
      hotPositions: [
        { title: '高级软件工程师', salary: '40-70K', count: 256 },
        { title: '游戏开发工程师', salary: '35-60K', count: 198 },
        { title: '产品经理', salary: '30-55K', count: 176 },
        { title: 'AI算法工程师', salary: '45-80K', count: 165 },
        { title: '运营经理', salary: '25-45K', count: 132 }
      ],
      activityIndex: 78
    },
    jobAdvice: {
      name: '腾讯',
      overallScore: 82,
      recommendation: '推荐',
      pros: [
        '薪资福利行业顶尖，年终奖丰厚',
        '公司稳定，业务多元，抗风险能力强',
        '技术积累深厚，学习成长空间大',
        '推行不加班文化，WLB逐步改善',
        '六险一金全额缴纳，保障完善'
      ],
      cons: [
        '大公司病明显，流程繁琐效率低',
        '晋升通道竞争激烈',
        '部分业务线（游戏）加班仍较多',
        '组织架构复杂，跨部门协作成本高'
      ],
      salaryRange: '25K-80K',
      interviewDifficulty: '较难',
      interviewTips: [
        '重点准备计算机基础和网络协议',
        '了解腾讯各产品线的最新动态',
        '准备好系统设计和项目经验',
        '关注游戏、社交、AI等技术方向'
      ],
      careerDevelopment: '双通道发展，技术和管理路线清晰，内部转岗机会多'
    },
    investment: {
      name: '腾讯',
      totalInvestment: '上市公司（港股00700）',
      investors: [
        { name: '南非报业集团(Naspers)', round: 'IPO前', amount: '战略投资' },
        { name: '公众股东', round: '港股上市', amount: '公开募股' }
      ],
      valuation: '约35000亿港币',
      latestRound: '港股00700.HK',
      fundingHistory: [
        { round: '天使轮', year: 1998, amount: '50万美元' },
        { round: 'A轮', year: 1999, amount: '220万美元' },
        { round: 'B轮', year: 2000, amount: '2000万美元' },
        { round: 'C轮', year: 2001, amount: '未公开' },
        { round: 'IPO', year: 2004, amount: '14.4亿港元' }
      ],
      ipoStatus: '2004年港股上市（00700.HK）',
      investmentScore: 90
    },
    socialSecurity: {
      name: '腾讯',
      complianceRate: 99,
      baseRatio: '全额缴纳',
      housingFundRate: '12%',
      averageBase: '28000元',
      months: ['2024-01', '2024-02', '2024-03', '2024-04', '2024-05', '2024-06'],
      paymentRecords: [99, 99, 100, 99, 100, 99],
      issues: [],
      overallRating: '优秀',
      riskLevel: '极低'
    },
    stock: {
      name: '腾讯',
      isListed: true,
      stockCode: '00700.HK',
      stockPrice: 388.6,
      ipoPlan: '已上市',
      ipoRumor: null,
      preIpoValuation: null,
      investmentHighlights: [
        '中国最大的社交平台运营商',
        '游戏业务全球领先',
        '微信生态商业化空间巨大',
        '持续回购股票，股东回报良好'
      ],
      investmentRisks: [
        '游戏版号政策不确定性',
        '短视频竞争加剧（抖音）',
        '监管政策变化风险',
        '海外业务拓展不及预期'
      ]
    },
    culture: {
      name: '腾讯',
      overallScore: 78,
      workStyle: '稳健务实，用户至上',
      workStyleRating: 4.0,
      values: [
        { name: '用户为本', score: 4.5 },
        { name: '科技向善', score: 4.0 },
        { name: '合作创新', score: 3.8 },
        { name: '开放共赢', score: 3.5 },
        { name: '追求卓越', score: 3.6 },
        { name: '诚信负责', score: 4.2 }
      ],
      perks: [
        '六险一金全额缴纳',
        '免费班车+免费早餐',
        '年度高端体检（家属也可享受）',
        '免费健身房+游泳池+篮球场',
        '股票期权激励',
        '15天带薪年假起'
      ],
      painPoints: [
        '大公司流程复杂，决策慢',
        '部分游戏部门加班严重',
        '内部竞争激烈，KPI压力大',
        '跨部门协作沟通成本高'
      ],
      wlbScore: 3.2,
      wlbDesc: '工作生活平衡一般',
      employeeSatisfaction: 75,
      turnoverRate: 12
    }
  },

  '阿里巴巴': {
    company: {
      name: '阿里巴巴',
      fullName: '阿里巴巴集团控股有限公司',
      industry: '互联网/电商',
      founded: '1999年',
      location: '浙江省杭州市',
      scale: '10000人以上',
      logo: 'https://img.icons8.com/color/200/alibaba.png',
      description: '阿里巴巴是中国最大的电子商务公司，业务涵盖电商（淘宝、天猫）、云计算（阿里云）、数字媒体、本地生活等多个领域，是全球领先的数字经济体。',
      tags: ['互联网', '电商', '云计算', '金融科技'],
      website: 'https://www.alibaba.com',
      status: '在营',
      registeredCapital: '5960万美元',
      legalPerson: '蒋芳',
      socialCreditCode: '91330100716105852F',
      employees: '约200000人'
    },
    annualReport: {
      name: '阿里巴巴',
      years: ['2021', '2022', '2023', '2024'],
      revenue: [8531, 8531, 8687, 9410],
      revenueUnit: '亿人民币',
      revenueGrowth: [41, 0, 2, 8],
      netProfit: [1433, 470, 655, 850],
      netProfitUnit: '亿人民币',
      netProfitGrowth: [-2, -67, 39, 30],
      employeeCount: [251000, 240000, 220000, 200000],
      rdInvestment: [545, 538, 560, 610],
      rdInvestmentUnit: '亿人民币',
      rdRatio: [6.4, 6.3, 6.4, 6.5],
      highlights: [
        '淘宝天猫GMV稳定增长',
        '阿里云收入突破千亿',
        '国际电商业务（速卖通/Lazada）快速增长',
        '组织架构大调整，分拆六大业务集团'
      ],
      warnings: [
        '连续多年裁员，员工总数下降约5万人',
        '净利润波动较大',
        '核心电商业务增速放缓'
      ]
    },
    laborArbitration: {
      name: '阿里巴巴',
      totalCases: 268,
      trend: [32, 45, 58, 72, 61],
      trendYears: ['2020', '2021', '2022', '2023', '2024'],
      categories: [
        { type: '违法解除劳动合同', count: 72, percentage: 27 },
        { type: '加班费争议', count: 58, percentage: 22 },
        { type: '年终奖争议', count: 42, percentage: 16 },
        { type: '竞业限制纠纷', count: 35, percentage: 13 },
        { type: '工伤赔偿', count: 28, percentage: 10 },
        { type: '其他', count: 33, percentage: 12 }
      ],
      winRate: { employee: 45, company: 55 },
      riskLevel: '偏高',
      typicalCases: [
        { title: '员工诉阿里违法解除劳动合同', year: 2024, result: '员工胜诉，赔偿28万元' },
        { title: '大规模裁员引发的集体仲裁', year: 2024, result: '调解结案，N+3补偿' },
        { title: '加班费争议仲裁', year: 2023, result: '员工部分胜诉' }
      ]
    },
    judicial: {
      name: '阿里巴巴',
      totalCases: 528,
      asPlaintiff: 312,
      asDefendant: 216,
      trend: [68, 82, 95, 112, 171],
      trendYears: ['2020', '2021', '2022', '2023', '2024'],
      categories: [
        { type: '知识产权侵权', count: 125, percentage: 24 },
        { type: '不正当竞争', count: 95, percentage: 18 },
        { type: '劳动争议', count: 78, percentage: 15 },
        { type: '合同纠纷', count: 65, percentage: 12 },
        { type: '反垄断相关', count: 52, percentage: 10 },
        { type: '消费者权益', count: 58, percentage: 11 },
        { type: '其他', count: 55, percentage: 10 }
      ],
      recentCases: [
        { title: '阿里巴巴诉某商家售假', year: 2024, result: '胜诉，赔偿300万元' },
        { title: '反垄断罚款后续诉讼', year: 2023, result: '已执行182亿罚款' },
        { title: '员工诉阿里P序列晋升不公', year: 2024, result: '调解结案' }
      ]
    },
    overtimeReview: {
      name: '阿里巴巴',
      avgWorkHours: 10.2,
      overtimeFrequency: '频繁',
      overtimeRating: 2.5,
      overtimeRatingDesc: '加班较严重',
      employeeReviews: {
        totalCount: 15680,
        positiveRate: 32,
        neutralRate: 28,
        negativeRate: 40,
        overallRating: 3.0,
        dimensions: {
          '薪资福利': 3.8,
          '工作生活平衡': 2.2,
          '职业发展': 3.2,
          '公司文化': 2.8,
          '管理层': 2.9,
          '工作环境': 3.5
        },
        hotComments: [
          { content: '阿里曾经是很好的公司，但现在裁员太多，人心惶惶。361绩效淘汰制度让人焦虑。', sentiment: 'negative', likes: 3256 },
          { content: '电商业务压力大，双十一期间基本住在公司。平时加班也很多。', sentiment: 'negative', likes: 2876 },
          { content: '薪资给的还可以，股票期权也有，但最近股价跌了不少。', sentiment: 'neutral', likes: 2345 },
          { content: '阿里云部门相对好一些，技术氛围不错，但也被裁了不少人。', sentiment: 'neutral', likes: 1987 },
          { content: '新管理层上任后有改善迹象，组织架构调整后效率有所提升。', sentiment: 'positive', likes: 1654 }
        ]
      }
    },
    bossActivity: {
      name: '阿里巴巴',
      totalPositions: 2986,
      activePositions: 1656,
      avgResponseTime: '3小时内',
      responseRate: 68,
      monthlyTrend: [280, 310, 340, 360, 366],
      monthlyTrendMonths: ['1月', '2月', '3月', '4月', '5月'],
      hotPositions: [
        { title: '高级Java开发工程师', salary: '35-60K', count: 186 },
        { title: '算法工程师', salary: '40-70K', count: 145 },
        { title: '产品经理', salary: '25-50K', count: 128 },
        { title: '运营专家', salary: '20-40K', count: 112 },
        { title: '云计算架构师', salary: '45-80K', count: 86 }
      ],
      activityIndex: 62
    },
    jobAdvice: {
      name: '阿里巴巴',
      overallScore: 62,
      recommendation: '谨慎考虑',
      pros: [
        '薪资水平较高，股票期权有长期价值',
        '电商和云计算领域技术积累深厚',
        '品牌影响力强，简历含金量高',
        '阿里云等业务有技术壁垒'
      ],
      cons: [
        '近期裁员频繁，稳定性差',
        '361绩效制度压力大',
        '加班文化严重，996现象存在',
        '组织架构调整频繁，方向不明确',
        '内部政治较复杂'
      ],
      salaryRange: '20K-70K',
      interviewDifficulty: '难',
      interviewTips: [
        '重点准备Java基础和分布式系统',
        '了解阿里技术栈（Spring Cloud、Dubbo等）',
        '准备好项目经验深度复盘',
        '关注电商、云计算、AI等技术方向'
      ],
      careerDevelopment: 'P序列技术路线和管理路线，但晋升竞争激烈，裁员风险需关注'
    },
    investment: {
      name: '阿里巴巴',
      totalInvestment: '上市公司（美股BABA/港股9988）',
      investors: [
        { name: '软银集团', round: '多轮', amount: '战略投资' },
        { name: '雅虎', round: '早期', amount: '10亿美元' },
        { name: '公众股东', round: '上市', amount: '公开募股' }
      ],
      valuation: '约18000亿港币',
      latestRound: '港股9988.HK / 纽交所BABA',
      fundingHistory: [
        { round: '天使轮', year: 1999, amount: '50万美元' },
        { round: 'A轮', year: 2000, amount: '2000万美元' },
        { round: 'B轮', year: 2004, amount: '8200万美元' },
        { round: 'C轮', year: 2005, amount: '10亿美元' },
        { round: 'IPO', year: 2014, amount: '250亿美元（美股）' },
        { round: '二次上市', year: 2019, amount: '港股二次上市' }
      ],
      ipoStatus: '2014年纽交所上市（BABA），2019年港股二次上市（9988.HK）',
      investmentScore: 72
    },
    socialSecurity: {
      name: '阿里巴巴',
      complianceRate: 94,
      baseRatio: '基本全额缴纳',
      housingFundRate: '12%',
      averageBase: '22000元',
      months: ['2024-01', '2024-02', '2024-03', '2024-04', '2024-05', '2024-06'],
      paymentRecords: [94, 93, 94, 95, 94, 95],
      issues: [
        { month: '2023-09', issue: '部分P序列外包员工社保断缴', status: '已整改' },
        { month: '2024-02', issue: '裁员期间部分员工社保衔接不及时', status: '已整改' }
      ],
      overallRating: '良好',
      riskLevel: '中等'
    },
    stock: {
      name: '阿里巴巴',
      isListed: true,
      stockCode: 'BABA(美股) / 9988.HK(港股)',
      stockPrice: 82.5,
      ipoPlan: '已上市',
      ipoRumor: null,
      preIpoValuation: null,
      investmentHighlights: [
        '中国最大的电商平台',
        '阿里云亚洲市场份额第一',
        '估值处于历史低位',
        '持续回购股票'
      ],
      investmentRisks: [
        '核心电商业务增速放缓',
        '拼多多等竞争对手冲击',
        '监管政策不确定性',
        '管理层变动频繁'
      ]
    },
    culture: {
      name: '阿里巴巴',
      overallScore: 58,
      workStyle: '狼性文化，拥抱变化',
      workStyleRating: 3.0,
      values: [
        { name: '客户第一', score: 3.5 },
        { name: '团队合作', score: 3.2 },
        { name: '拥抱变化', score: 3.8 },
        { name: '诚信', score: 3.0 },
        { name: '激情', score: 3.5 },
        { name: '敬业', score: 3.2 }
      ],
      perks: [
        '股票期权激励',
        '免费三餐+下午茶',
        '年度高端体检',
        'iHome无息贷款（购房）',
        '弹性工作（部分部门）',
        '阿里日带薪假'
      ],
      painPoints: [
        '361绩效淘汰制度压力大',
        '996加班文化严重',
        '频繁裁员，人心不稳',
        '拥抱变化=频繁调整组织架构',
        '内部政治文化较重'
      ],
      wlbScore: 2.0,
      wlbDesc: '工作生活平衡较差',
      employeeSatisfaction: 55,
      turnoverRate: 22
    }
  },

  '华为': {
    company: {
      name: '华为',
      fullName: '华为技术有限公司',
      industry: '通信/科技',
      founded: '1987年',
      location: '广东省深圳市',
      scale: '10000人以上',
      logo: 'https://img.icons8.com/color/200/huawei-logo.png',
      description: '华为是全球领先的ICT（信息与通信）基础设施和智能终端提供商，业务涵盖运营商网络、企业网络、消费者终端、云计算和智能汽车解决方案等领域。',
      tags: ['通信', '5G', '芯片', '智能终端', '云计算'],
      website: 'https://www.huawei.com',
      status: '在营',
      registeredCapital: '4044113万元人民币',
      legalPerson: '赵明路',
      socialCreditCode: '9144030071526726XG',
      employees: '约207000人'
    },
    annualReport: {
      name: '华为',
      years: ['2021', '2022', '2023', '2024'],
      revenue: [6368, 6423, 7042, 7800],
      revenueUnit: '亿人民币',
      revenueGrowth: [-29, 1, 10, 11],
      netProfit: [1137, 356, 870, 1050],
      netProfitUnit: '亿人民币',
      netProfitGrowth: [76, -69, 144, 21],
      employeeCount: [195000, 207000, 207000, 207000],
      rdInvestment: [1427, 1615, 1647, 1780],
      rdInvestmentUnit: '亿人民币',
      rdRatio: [22.4, 25.1, 23.4, 22.8],
      highlights: [
        '研发投入占比全球前列，连续多年超20%',
        '鸿蒙系统（HarmonyOS）用户突破4亿',
        'Mate 60系列手机热销，芯片自主突破',
        '智能汽车解决方案业务快速增长',
        '5G专利数量全球第一'
      ]
    },
    laborArbitration: {
      name: '华为',
      totalCases: 156,
      trend: [22, 28, 35, 42, 29],
      trendYears: ['2020', '2021', '2022', '2023', '2024'],
      categories: [
        { type: '加班费争议', count: 48, percentage: 31 },
        { type: '违法解除劳动合同', count: 35, percentage: 22 },
        { type: '竞业限制纠纷', count: 28, percentage: 18 },
        { type: '年终奖争议', count: 22, percentage: 14 },
        { type: '工伤赔偿', count: 12, percentage: 8 },
        { type: '其他', count: 11, percentage: 7 }
      ],
      winRate: { employee: 35, company: 65 },
      riskLevel: '中等',
      typicalCases: [
        { title: '员工诉华为加班费争议', year: 2024, result: '调解结案' },
        { title: '前员工竞业限制违约纠纷', year: 2023, result: '公司胜诉，违约金200万元' },
        { title: '员工诉华为违法解除劳动合同', year: 2023, result: '公司胜诉' }
      ]
    },
    judicial: {
      name: '华为',
      totalCases: 386,
      asPlaintiff: 245,
      asDefendant: 141,
      trend: [52, 65, 78, 92, 99],
      trendYears: ['2020', '2021', '2022', '2023', '2024'],
      categories: [
        { type: '专利侵权', count: 98, percentage: 25 },
        { type: '合同纠纷', count: 65, percentage: 17 },
        { type: '不正当竞争', count: 52, percentage: 13 },
        { type: '劳动争议', count: 48, percentage: 12 },
        { type: '商标侵权', count: 38, percentage: 10 },
        { type: '国际贸易纠纷', count: 45, percentage: 12 },
        { type: '其他', count: 40, percentage: 11 }
      ],
      recentCases: [
        { title: '华为诉某公司5G专利侵权', year: 2024, result: '胜诉，赔偿3500万元' },
        { title: '华为诉三星专利侵权', year: 2024, result: '和解，达成专利交叉许可' },
        { title: '美国制裁相关诉讼', year: 2023, result: '进行中' }
      ]
    },
    overtimeReview: {
      name: '华为',
      avgWorkHours: 11.0,
      overtimeFrequency: '非常频繁',
      overtimeRating: 1.8,
      overtimeRatingDesc: '加班非常严重',
      employeeReviews: {
        totalCount: 14250,
        positiveRate: 30,
        neutralRate: 25,
        negativeRate: 45,
        overallRating: 3.0,
        dimensions: {
          '薪资福利': 4.2,
          '工作生活平衡': 1.8,
          '职业发展': 3.5,
          '公司文化': 2.5,
          '管理层': 2.8,
          '工作环境': 3.2
        },
        hotComments: [
          { content: '华为的奋斗者文化是真的狠，基本没有周末，晚上10点下班算早的。但薪资确实给得高。', sentiment: 'negative', likes: 4562 },
          { content: '在华为能学到很多东西，技术和管理都很专业。但代价是牺牲全部个人生活。', sentiment: 'neutral', likes: 3876 },
          { content: '狼性文化不是说说而已，不适合想要工作生活平衡的人。但如果你愿意拼，回报也高。', sentiment: 'neutral', likes: 3245 },
          { content: '分红和年终奖是真的多，干几年能攒不少钱。但身体也垮了不少。', sentiment: 'neutral', likes: 2987 },
          { content: '海外派驻机会多，补贴也高，但离家太远，家庭关系难维护。', sentiment: 'negative', likes: 2565 }
        ]
      }
    },
    bossActivity: {
      name: '华为',
      totalPositions: 3568,
      activePositions: 2056,
      avgResponseTime: '4小时内',
      responseRate: 65,
      monthlyTrend: [350, 380, 420, 460, 446],
      monthlyTrendMonths: ['1月', '2月', '3月', '4月', '5月'],
      hotPositions: [
        { title: '高级通信工程师', salary: '35-60K', count: 198 },
        { title: '芯片设计工程师', salary: '40-75K', count: 156 },
        { title: '嵌入式开发工程师', salary: '30-55K', count: 132 },
        { title: 'AI算法工程师', salary: '40-70K', count: 118 },
        { title: '自动驾驶工程师', salary: '45-80K', count: 96 }
      ],
      activityIndex: 70
    },
    jobAdvice: {
      name: '华为',
      overallScore: 65,
      recommendation: '视个人情况而定',
      pros: [
        '薪资水平高，年终奖和分红丰厚',
        '技术研发实力全球顶尖',
        '5G、芯片、通信领域无可替代的平台',
        '内部培训和成长体系完善',
        '员工持股计划回报丰厚'
      ],
      cons: [
        '加班极其严重，几乎没有个人时间',
        '奋斗者协议压力大',
        '海外派遣频繁，家庭难兼顾',
        '企业文化强势，个人空间小',
        '美国制裁影响部分业务'
      ],
      salaryRange: '20K-75K',
      interviewDifficulty: '很难',
      interviewTips: [
        '重点准备通信协议和网络基础',
        '了解华为业务线和最新技术动态',
        '准备好技术深度面试',
        '关注5G、AI、芯片、自动驾驶方向'
      ],
      careerDevelopment: '技术专家和管理者双通道，内部晋升体系完善，但加班强度大'
    },
    investment: {
      name: '华为',
      totalInvestment: '非上市公司（100%员工持股）',
      investors: [
        { name: '员工持股计划', round: '内部', amount: '100%股权' }
      ],
      valuation: '未公开（估计数千亿人民币）',
      latestRound: '非上市公司',
      fundingHistory: [
        { round: '创立', year: 1987, amount: '2.1万元人民币' },
        { round: '员工持股', year: 1990, amount: '内部融资' }
      ],
      ipoStatus: '任正非多次表示不会上市',
      investmentScore: 85
    },
    socialSecurity: {
      name: '华为',
      complianceRate: 98,
      baseRatio: '全额缴纳',
      housingFundRate: '12%',
      averageBase: '26000元',
      months: ['2024-01', '2024-02', '2024-03', '2024-04', '2024-05', '2024-06'],
      paymentRecords: [98, 98, 99, 98, 99, 98],
      issues: [],
      overallRating: '优秀',
      riskLevel: '极低'
    },
    stock: {
      name: '华为',
      isListed: false,
      stockCode: null,
      stockPrice: null,
      ipoPlan: '官方表示不会上市',
      ipoRumor: '市场偶尔传闻，但任正非多次公开表示华为不会上市',
      preIpoValuation: null,
      investmentHighlights: [
        '全球最大的通信设备制造商',
        '5G专利数量全球第一',
        '自主研发芯片取得突破',
        '鸿蒙生态系统快速成长'
      ],
      investmentRisks: [
        '非上市公司，无法直接投资',
        '美国制裁持续影响',
        '消费者业务受芯片供应制约',
        '过度依赖通信设备业务'
      ]
    },
    culture: {
      name: '华为',
      overallScore: 55,
      workStyle: '狼性文化，奋斗者为本',
      workStyleRating: 2.8,
      values: [
        { name: '以客户为中心', score: 4.0 },
        { name: '以奋斗者为本', score: 3.8 },
        { name: '长期艰苦奋斗', score: 4.2 },
        { name: '坚持自我批判', score: 3.0 },
        { name: '团队合作', score: 3.5 },
        { name: '开放创新', score: 3.2 }
      ],
      perks: [
        '高薪资+丰厚年终奖+分红',
        '员工持股计划',
        '完善的培训体系',
        '海外派遣补贴丰厚',
        '内部食堂+宿舍',
        '商业保险补充'
      ],
      painPoints: [
        '加班极其严重，几乎没有周末',
        '奋斗者协议强制签署',
        '海外派遣频繁，家庭难兼顾',
        '军事化管理风格',
        '内部竞争激烈，末位淘汰'
      ],
      wlbScore: 1.5,
      wlbDesc: '工作生活平衡极差',
      employeeSatisfaction: 52,
      turnoverRate: 15
    }
  },

  '小米': {
    company: {
      name: '小米',
      fullName: '小米科技有限责任公司',
      industry: '互联网/消费电子',
      founded: '2010年',
      location: '北京市海淀区',
      scale: '10000人以上',
      logo: 'https://img.icons8.com/color/200/xiaomi--v1.png',
      description: '小米是一家以智能手机、智能硬件和IoT平台为核心的消费电子公司，旗下拥有小米手机、Redmi、米家等品牌，同时布局新能源汽车（小米SU7）等新领域。',
      tags: ['消费电子', '智能手机', 'IoT', '新能源汽车'],
      website: 'https://www.mi.com',
      status: '在营',
      registeredCapital: '185000万元人民币',
      legalPerson: '雷军',
      socialCreditCode: '91110108551385082Q',
      employees: '约35000人'
    },
    annualReport: {
      name: '小米',
      years: ['2021', '2022', '2023', '2024'],
      revenue: [3283, 2800, 2710, 3650],
      revenueUnit: '亿人民币',
      revenueGrowth: [33, -15, -3, 35],
      netProfit: [220, 85, 193, 320],
      netProfitUnit: '亿人民币',
      netProfitGrowth: [70, -61, 127, 66],
      employeeCount: [30000, 28000, 32000, 35000],
      rdInvestment: [132, 160, 191, 240],
      rdInvestmentUnit: '亿人民币',
      rdRatio: [4.0, 5.7, 7.0, 6.6],
      highlights: [
        '小米SU7汽车上市首月销量超预期',
        '全球智能手机出货量稳居前三',
        '小米14系列高端化战略成功',
        'AI大模型全面接入小米生态',
        'IoT连接设备数超7亿'
      ]
    },
    laborArbitration: {
      name: '小米',
      totalCases: 76,
      trend: [10, 14, 16, 20, 16],
      trendYears: ['2020', '2021', '2022', '2023', '2024'],
      categories: [
        { type: '违法解除劳动合同', count: 20, percentage: 26 },
        { type: '加班费争议', count: 18, percentage: 24 },
        { type: '竞业限制纠纷', count: 12, percentage: 16 },
        { type: '年终奖争议', count: 10, percentage: 13 },
        { type: '工伤赔偿', count: 8, percentage: 11 },
        { type: '其他', count: 8, percentage: 10 }
      ],
      winRate: { employee: 40, company: 60 },
      riskLevel: '较低',
      typicalCases: [
        { title: '员工诉小米违法解除劳动合同', year: 2024, result: '调解结案，赔偿15万元' },
        { title: '加班费争议', year: 2023, result: '员工部分胜诉' },
        { title: '年终奖发放争议', year: 2023, result: '调解结案' }
      ]
    },
    judicial: {
      name: '小米',
      totalCases: 198,
      asPlaintiff: 125,
      asDefendant: 73,
      trend: [25, 32, 38, 48, 55],
      trendYears: ['2020', '2021', '2022', '2023', '2024'],
      categories: [
        { type: '专利侵权', count: 52, percentage: 26 },
        { type: '商标侵权', count: 35, percentage: 18 },
        { type: '不正当竞争', count: 28, percentage: 14 },
        { type: '合同纠纷', count: 25, percentage: 13 },
        { type: '消费者权益', count: 28, percentage: 14 },
        { type: '劳动争议', count: 18, percentage: 9 },
        { type: '其他', count: 12, percentage: 6 }
      ],
      recentCases: [
        { title: '小米诉某公司专利侵权', year: 2024, result: '胜诉，赔偿800万元' },
        { title: '消费者诉小米手机质量纠纷', year: 2024, result: '调解结案' },
        { title: '小米诉某公司商标侵权', year: 2023, result: '胜诉，赔偿300万元' }
      ]
    },
    overtimeReview: {
      name: '小米',
      avgWorkHours: 9.0,
      overtimeFrequency: '一般',
      overtimeRating: 3.5,
      overtimeRatingDesc: '加班中等',
      employeeReviews: {
        totalCount: 9860,
        positiveRate: 52,
        neutralRate: 28,
        negativeRate: 20,
        overallRating: 3.8,
        dimensions: {
          '薪资福利': 3.8,
          '工作生活平衡': 3.2,
          '职业发展': 3.5,
          '公司文化': 3.8,
          '管理层': 3.6,
          '工作环境': 3.8
        },
        hotComments: [
          { content: '小米整体氛围还不错，雷总的个人魅力也加分。加班不算特别严重，比很多互联网公司好。', sentiment: 'positive', likes: 2562 },
          { content: '手机部门加班多一些，IoT部门相对轻松。看具体团队。', sentiment: 'neutral', likes: 2187 },
          { content: '薪资在行业中上水平，期权也有。汽车业务是新的增长点，加入是个好机会。', sentiment: 'positive', likes: 1945 },
          { content: '公司扁平化管理，沟通比较顺畅。但晋升空间有限，天花板明显。', sentiment: 'neutral', likes: 1654 },
          { content: '性价比高的选择，适合想要相对平衡又不错薪资的人。', sentiment: 'positive', likes: 1432 }
        ]
      }
    },
    bossActivity: {
      name: '小米',
      totalPositions: 2568,
      activePositions: 1456,
      avgResponseTime: '1天内',
      responseRate: 75,
      monthlyTrend: [240, 280, 310, 340, 286],
      monthlyTrendMonths: ['1月', '2月', '3月', '4月', '5月'],
      hotPositions: [
        { title: 'Android开发工程师', salary: '25-50K', count: 156 },
        { title: '汽车研发工程师', salary: '30-55K', count: 132 },
        { title: '硬件工程师', salary: '20-40K', count: 118 },
        { title: '产品经理', salary: '20-40K', count: 96 },
        { title: 'AI算法工程师', salary: '35-65K', count: 85 }
      ],
      activityIndex: 72
    },
    jobAdvice: {
      name: '小米',
      overallScore: 78,
      recommendation: '推荐',
      pros: [
        '工作生活平衡相对较好',
        '公司文化开放，扁平化管理',
        '薪资待遇合理，期权激励',
        '汽车业务带来新的发展机会',
        '品牌影响力强，产品线丰富'
      ],
      cons: [
        '与BAT相比技术深度稍逊',
        '高端人才吸引力不如头部大厂',
        '手机业务利润率低',
        '部分部门加班仍较多'
      ],
      salaryRange: '18K-65K',
      interviewDifficulty: '中等',
      interviewTips: [
        '重点准备Android开发和移动端技术',
        '了解小米产品生态和最新动态',
        '关注小米汽车SU7相关技术',
        '准备好项目经验和技术深度展示'
      ],
      careerDevelopment: '技术和管理双通道，汽车业务带来新的晋升机会'
    },
    investment: {
      name: '小米',
      totalInvestment: '上市公司（港股1810）',
      investors: [
        { name: '顺为资本', round: 'A轮', amount: '战略投资' },
        { name: '晨兴资本', round: 'A轮', amount: '战略投资' },
        { name: '公众股东', round: '上市', amount: '公开募股' }
      ],
      valuation: '约5000亿港币',
      latestRound: '港股1810.HK',
      fundingHistory: [
        { round: '天使轮', year: 2010, amount: '未公开' },
        { round: 'A轮', year: 2011, amount: '9000万美元' },
        { round: 'B轮', year: 2012, amount: '2.16亿美元' },
        { round: 'C轮', year: 2013, amount: '未公开' },
        { round: 'IPO', year: 2018, amount: '54亿美元（港股）' }
      ],
      ipoStatus: '2018年港股上市（1810.HK）',
      investmentScore: 75
    },
    socialSecurity: {
      name: '小米',
      complianceRate: 97,
      baseRatio: '全额缴纳',
      housingFundRate: '12%',
      averageBase: '20000元',
      months: ['2024-01', '2024-02', '2024-03', '2024-04', '2024-05', '2024-06'],
      paymentRecords: [97, 97, 98, 97, 98, 97],
      issues: [],
      overallRating: '优秀',
      riskLevel: '低'
    },
    stock: {
      name: '小米',
      isListed: true,
      stockCode: '1810.HK',
      stockPrice: 52.8,
      ipoPlan: '已上市',
      ipoRumor: null,
      preIpoValuation: null,
      investmentHighlights: [
        '全球智能手机出货量前三',
        '小米SU7汽车打开第二增长曲线',
        'IoT生态全球领先',
        'AI大模型全面布局'
      ],
      investmentRisks: [
        '手机业务竞争激烈利润率低',
        '汽车业务投入大回报周期长',
        '高端化转型面临挑战',
        '海外市场地缘政治风险'
      ]
    },
    culture: {
      name: '小米',
      overallScore: 75,
      workStyle: '扁平高效，工程师文化',
      workStyleRating: 4.0,
      values: [
        { name: '真诚热爱', score: 4.0 },
        { name: '用户导向', score: 3.8 },
        { name: '工程师文化', score: 4.2 },
        { name: '性价比', score: 3.5 },
        { name: '持续创新', score: 3.8 },
        { name: '开放透明', score: 3.6 }
      ],
      perks: [
        '股票期权激励',
        '免费三餐+下午茶',
        '年度体检',
        '内购优惠（小米产品）',
        '弹性工作制',
        '团建活动丰富'
      ],
      painPoints: [
        '部分核心部门加班较多',
        '与头部大厂相比薪资略低',
        '晋升天花板相对较低',
        '手机行业竞争压力大'
      ],
      wlbScore: 3.5,
      wlbDesc: '工作生活平衡较好',
      employeeSatisfaction: 72,
      turnoverRate: 14
    }
  }
};

// 公司名称别名映射（支持模糊搜索）
const companyAliases = {
  '字节跳动': ['字节跳动', '字节', 'bytedance', '抖音', '今日头条', 'tiktok'],
  '腾讯': ['腾讯', 'tencent', '企鹅', '鹅厂', 'qq', '微信'],
  '阿里巴巴': ['阿里巴巴', '阿里', 'alibaba', '淘宝', '天猫', '淘宝天猫', '阿里云'],
  '华为': ['华为', 'huawei', '荣耀', '鸿蒙'],
  '小米': ['小米', 'xiaomi', 'mi', '红米', 'redmi', '米家']
};

// ============================================================
// 工具函数
// ============================================================

/**
 * 解析URL查询参数
 */
function parseQuery(reqUrl) {
  const parsed = url.parse(reqUrl, true);
  return parsed.query;
}

/**
 * 根据名称查找公司（支持模糊匹配）
 */
function findCompany(name) {
  if (!name) return null;

  const searchName = name.trim().toLowerCase();

  // 精确匹配
  if (companyDB[name.trim()]) {
    return name.trim();
  }

  // 别名匹配
  for (const [key, aliases] of Object.entries(companyAliases)) {
    if (aliases.some(alias => alias.toLowerCase() === searchName)) {
      return key;
    }
  }

  // 模糊匹配（包含关系）
  for (const key of Object.keys(companyDB)) {
    if (key.toLowerCase().includes(searchName) || searchName.includes(key.toLowerCase())) {
      return key;
    }
  }

  // 别名模糊匹配
  for (const [key, aliases] of Object.entries(companyAliases)) {
    if (aliases.some(alias => alias.toLowerCase().includes(searchName) || searchName.includes(alias.toLowerCase()))) {
      return key;
    }
  }

  return null;
}

/**
 * 搜索公司（返回匹配列表）
 */
function searchCompanies(query) {
  if (!query) return [];

  const searchQuery = query.trim().toLowerCase();
  const results = [];

  for (const [name, data] of Object.entries(companyDB)) {
    let match = false;
    let matchType = '';

    // 精确匹配
    if (name.toLowerCase() === searchQuery) {
      match = true;
      matchType = 'exact';
    }
    // 别名匹配
    else if (companyAliases[name] && companyAliases[name].some(a => a.toLowerCase() === searchQuery)) {
      match = true;
      matchType = 'alias';
    }
    // 包含匹配
    else if (name.toLowerCase().includes(searchQuery) || searchQuery.includes(name.toLowerCase())) {
      match = true;
      matchType = 'partial';
    }
    // 别名包含匹配
    else if (companyAliases[name] && companyAliases[name].some(a => a.toLowerCase().includes(searchQuery))) {
      match = true;
      matchType = 'alias';
    }
    // 行业/标签匹配
    else if (data.company.tags.some(tag => tag.toLowerCase().includes(searchQuery))) {
      match = true;
      matchType = 'tag';
    }

    if (match) {
      results.push({
        name: name,
        fullName: data.company.fullName,
        industry: data.company.industry,
        location: data.company.location,
        scale: data.company.scale,
        matchType: matchType
      });
    }
  }

  return results;
}

/**
 * 发送JSON响应
 */
function sendJSON(res, statusCode, data) {
  const response = {
    code: statusCode,
    data: data,
    message: statusCode === 200 ? 'success' : 'error'
  };

  res.writeHead(statusCode, {
    'Content-Type': 'application/json; charset=utf-8',
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type, Authorization'
  });

  res.end(JSON.stringify(response, null, 2));
}

/**
 * 发送错误响应
 */
function sendError(res, statusCode, message) {
  sendJSON(res, statusCode, { error: message });
}

// ============================================================
// 路由处理
// ============================================================

function handleRequest(req, res) {
  const parsedUrl = url.parse(req.url, true);
  const pathname = parsedUrl.pathname;
  const query = parsedUrl.query;

  // 处理 CORS 预检请求
  if (req.method === 'OPTIONS') {
    res.writeHead(200, {
      'Content-Type': 'application/json; charset=utf-8',
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
      'Access-Control-Allow-Headers': 'Content-Type, Authorization'
    });
    res.end();
    return;
  }

  // 静态文件服务（非 /api 路径）
  if (!pathname.startsWith('/api')) {
    // 默认首页
    let filePath = pathname === '/' ? '/index.html' : pathname;
    if (serveStaticFile(res, filePath)) {
      return;
    }
    // SPA fallback: 未找到的路径返回 index.html
    serveStaticFile(res, '/index.html');
    return;
  }

  // 只处理 GET 请求（API）
  if (req.method !== 'GET') {
    sendError(res, 405, 'Method Not Allowed. Only GET requests are supported.');
    return;
  }

  // 路由分发
  switch (pathname) {
    case '/api/company': {
      const companyName = findCompany(query.name);
      if (!companyName) {
        sendError(res, 404, '未找到该公司信息，请检查公司名称');
        return;
      }
      sendJSON(res, 200, companyDB[companyName].company);
      break;
    }

    case '/api/annual-report': {
      const companyName = findCompany(query.name);
      if (!companyName) {
        sendError(res, 404, '未找到该公司年报数据');
        return;
      }
      sendJSON(res, 200, companyDB[companyName].annualReport);
      break;
    }

    case '/api/labor-arbitration': {
      const companyName = findCompany(query.name);
      if (!companyName) {
        sendError(res, 404, '未找到该公司劳动仲裁数据');
        return;
      }
      sendJSON(res, 200, companyDB[companyName].laborArbitration);
      break;
    }

    case '/api/judicial': {
      const companyName = findCompany(query.name);
      if (!companyName) {
        sendError(res, 404, '未找到该公司司法数据');
        return;
      }
      sendJSON(res, 200, companyDB[companyName].judicial);
      break;
    }

    case '/api/overtime-review': {
      const companyName = findCompany(query.name);
      if (!companyName) {
        sendError(res, 404, '未找到该公司加班及评价数据');
        return;
      }
      sendJSON(res, 200, companyDB[companyName].overtimeReview);
      break;
    }

    case '/api/boss-activity': {
      const companyName = findCompany(query.name);
      if (!companyName) {
        sendError(res, 404, '未找到该公司BOSS直聘数据');
        return;
      }
      sendJSON(res, 200, companyDB[companyName].bossActivity);
      break;
    }

    case '/api/job-advice': {
      const companyName = findCompany(query.name);
      if (!companyName) {
        sendError(res, 404, '未找到该公司求职建议数据');
        return;
      }
      sendJSON(res, 200, companyDB[companyName].jobAdvice);
      break;
    }

    case '/api/investment': {
      const companyName = findCompany(query.name);
      if (!companyName) {
        sendError(res, 404, '未找到该公司投资数据');
        return;
      }
      sendJSON(res, 200, companyDB[companyName].investment);
      break;
    }

    case '/api/social-security': {
      const companyName = findCompany(query.name);
      if (!companyName) {
        sendError(res, 404, '未找到该公司社保数据');
        return;
      }
      sendJSON(res, 200, companyDB[companyName].socialSecurity);
      break;
    }

    case '/api/stock': {
      const companyName = findCompany(query.name);
      if (!companyName) {
        sendError(res, 404, '未找到该公司股票数据');
        return;
      }
      sendJSON(res, 200, companyDB[companyName].stock);
      break;
    }

    case '/api/culture': {
      const companyName = findCompany(query.name);
      if (!companyName) {
        sendError(res, 404, '未找到该公司企业文化数据');
        return;
      }
      sendJSON(res, 200, companyDB[companyName].culture);
      break;
    }

    case '/api/search': {
      const q = query.q;
      if (!q) {
        sendError(res, 400, '请提供搜索关键词（q参数）');
        return;
      }
      const results = searchCompanies(q);
      if (results.length === 0) {
        sendJSON(res, 200, { results: [], message: '未找到匹配的公司' });
      } else {
        sendJSON(res, 200, { results: results, total: results.length });
      }
      break;
    }

    case '/api':
    case '/': {
      // API首页，返回接口列表
      sendJSON(res, 200, {
        name: '企业背查API服务',
        version: '1.0.0',
        endpoints: [
          'GET /api/company?name=xxx - 获取公司基本信息',
          'GET /api/annual-report?name=xxx - 获取年报数据',
          'GET /api/labor-arbitration?name=xxx - 获取劳动仲裁数据',
          'GET /api/judicial?name=xxx - 获取司法判决数据',
          'GET /api/overtime-review?name=xxx - 获取加班及员工评价数据',
          'GET /api/boss-activity?name=xxx - 获取BOSS直聘活跃度数据',
          'GET /api/job-advice?name=xxx - 获取求职建议数据',
          'GET /api/investment?name=xxx - 获取投资情况数据',
          'GET /api/social-security?name=xxx - 获取社保缴纳数据',
          'GET /api/stock?name=xxx - 获取股票投资数据',
          'GET /api/culture?name=xxx - 获取企业文化数据',
          'GET /api/search?q=xxx - 搜索公司'
        ],
        supportedCompanies: ['字节跳动', '腾讯', '阿里巴巴', '华为', '小米']
      });
      break;
    }

    default: {
      sendError(res, 404, '接口不存在。请访问 /api 查看可用接口列表。');
      break;
    }
  }
}

// ============================================================
// 导出（供 Vercel Serverless Function 使用）
// ============================================================
module.exports = { handleRequest };

// ============================================================
// 创建并启动服务器（仅本地开发时执行）
// ============================================================

if (require.main === module) {
  const PORT = process.env.PORT || 3000;

  const server = http.createServer(handleRequest);

  server.listen(PORT, () => {
    console.log('========================================');
    console.log('  企业背查API服务已启动');
    console.log(`  地址: http://localhost:${PORT}`);
    console.log(`  接口文档: http://localhost:${PORT}/api`);
    console.log('========================================');
    console.log('  支持的公司: 字节跳动、腾讯、阿里巴巴、华为、小米');
    console.log(`  示例: http://localhost:${PORT}/api/company?name=字节跳动`);
    console.log(`  搜索: http://localhost:${PORT}/api/search?q=阿里`);
    console.log('========================================');
  });
}
