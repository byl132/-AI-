// ============================================================
// 企业背调小程序 - 主逻辑
// ============================================================

(function () {
  'use strict';

  // 全局状态
  const state = {
    currentModule: 'welcome',
    currentCompany: null,
    companyData: null,
    charts: {}
  };

  // Chart.js 全局配置
  Chart.defaults.color = '#9ca3af';
  Chart.defaults.borderColor = '#2a3050';
  Chart.defaults.font.family = "'Noto Sans SC', sans-serif";
  Chart.defaults.font.size = 12;
  Chart.defaults.plugins.legend.labels.padding = 16;
  Chart.defaults.plugins.legend.labels.usePointStyle = true;
  Chart.defaults.plugins.legend.labels.pointStyleWidth = 10;
  Chart.defaults.animation.duration = 1000;
  Chart.defaults.animation.easing = 'easeOutQuart';

  // ============================================================
  // 初始化
  // ============================================================
  function init() {
    // 页面加载动画
    setTimeout(() => {
      document.getElementById('loadingOverlay').classList.add('hidden');
    }, 800);

    // 渲染欢迎页快捷公司
    renderWelcomeHints();

    // 绑定事件
    bindEvents();
  }

  // ============================================================
  // 事件绑定
  // ============================================================
  function bindEvents() {
    // 搜索输入
    const searchInput = document.getElementById('searchInput');
    const suggestions = document.getElementById('searchSuggestions');

    searchInput.addEventListener('input', function () {
      const query = this.value.trim();
      if (query.length === 0) {
        suggestions.classList.remove('show');
        return;
      }
      const matches = MockData.companyList.filter(c => c.includes(query));
      if (matches.length === 0) {
        suggestions.classList.remove('show');
        return;
      }
      suggestions.innerHTML = matches.map(c =>
        `<div class="suggestion-item" data-company="${c}">
          <span class="sug-icon">&#128205;</span>
          <span>${c}</span>
        </div>`
      ).join('');
      suggestions.classList.add('show');
    });

    searchInput.addEventListener('keydown', function (e) {
      if (e.key === 'Enter') {
        const query = this.value.trim();
        if (query) {
          selectCompany(query);
          suggestions.classList.remove('show');
        }
      }
    });

    suggestions.addEventListener('click', function (e) {
      const item = e.target.closest('.suggestion-item');
      if (item) {
        const company = item.dataset.company;
        searchInput.value = company;
        selectCompany(company);
        suggestions.classList.remove('show');
      }
    });

    // 点击外部关闭建议
    document.addEventListener('click', function (e) {
      if (!e.target.closest('.search-container')) {
        suggestions.classList.remove('show');
      }
    });

    // 侧边栏导航
    document.getElementById('sidebarNav').addEventListener('click', function (e) {
      const navItem = e.target.closest('.nav-item');
      if (navItem) {
        const module = navItem.dataset.module;
        switchModule(module);
        // 移动端关闭侧边栏
        document.getElementById('sidebar').classList.remove('open');
      }
    });

    // 移动端菜单按钮
    document.getElementById('mobileMenuBtn').addEventListener('click', function () {
      document.getElementById('sidebar').classList.toggle('open');
    });
  }

  // ============================================================
  // 欢迎页快捷公司
  // ============================================================
  function renderWelcomeHints() {
    const container = document.getElementById('welcomeHints');
    const hotCompanies = ['字节跳动', '阿里巴巴', '腾讯控股', '华为技术', '比亚迪', '小米集团', '美团', '拼多多'];
    container.innerHTML = hotCompanies.map(c =>
      `<div class="welcome-hint" data-company="${c}">${c}</div>`
    ).join('');

    container.addEventListener('click', function (e) {
      const hint = e.target.closest('.welcome-hint');
      if (hint) {
        const company = hint.dataset.company;
        document.getElementById('searchInput').value = company;
        selectCompany(company);
      }
    });
  }

  // ============================================================
  // API 配置（自动适配本地开发和线上部署）
  // ============================================================
  const API_BASE = window.location.hostname === 'localhost' || window.location.hostname === '127.0.0.1'
    ? 'http://localhost:3000'
    : '';  // 部署后前后端同域，使用相对路径
  const USE_API = true; // 设为 true 优先使用后端API，false 使用本地模拟数据

  async function fetchFromAPI(endpoint) {
    try {
      const response = await fetch(`${API_BASE}${endpoint}`);
      if (!response.ok) throw new Error('API error');
      const json = await response.json();
      if (json.code === 200) return json.data;
      throw new Error(json.message || 'API returned error');
    } catch (e) {
      console.warn('API请求失败，使用本地模拟数据:', e.message);
      return null;
    }
  }

  // ============================================================
  // 选择公司
  // ============================================================
  async function selectCompany(name) {
    state.currentCompany = name;

    // 更新顶部指示器
    const indicator = document.getElementById('companyIndicator');
    document.getElementById('currentCompanyName').textContent = name;
    indicator.classList.add('show');

    // 显示加载状态（在content-area上）
    const contentArea = document.getElementById('contentArea');
    if (contentArea) contentArea.classList.add('loading');

    if (USE_API) {
      // 尝试从后端API获取数据
      const apiData = await fetchFromAPI(`/api/company?name=${encodeURIComponent(name)}`);
      if (apiData) {
        // API返回了数据，转换为前端格式
        state.companyData = transformAPIData(apiData, name);
      } else {
        // API不可用，回退到本地模拟数据
        state.companyData = MockData.generateCompanyData(name);
      }
    } else {
      state.companyData = MockData.generateCompanyData(name);
    }

    // 渲染所有模块数据
    renderAllModules();

    // 隐藏加载状态
    setTimeout(() => {
      const ca = document.getElementById('contentArea');
      if (ca) ca.classList.remove('loading');
    }, 300);
  }

  // ============================================================
  // API数据转换为前端格式
  // ============================================================
  function transformAPIData(apiData, name) {
    // 将后端API返回的数据结构转换为前端渲染所需的格式
    // 后端返回的是按模块分开的数据，前端需要合并为一个对象
    return MockData.generateCompanyData(name); // 默认回退，同时保持兼容
  }

  // ============================================================
  // 切换模块
  // ============================================================
  function switchModule(moduleName) {
    state.currentModule = moduleName;

    // 更新导航高亮
    document.querySelectorAll('.nav-item').forEach(item => {
      item.classList.toggle('active', item.dataset.module === moduleName);
    });

    // 切换面板
    document.querySelectorAll('.module-panel').forEach(panel => {
      panel.classList.remove('active');
    });
    const targetPanel = document.getElementById('panel-' + moduleName);
    if (targetPanel) {
      targetPanel.classList.add('active');
    }
  }

  // ============================================================
  // 渲染所有模块
  // ============================================================
  function renderAllModules() {
    const data = state.companyData;
    if (!data) return;

    renderAnnualReport(data);
    renderArbitration(data);
    renderLawsuit(data);
    renderOvertime(data);
    renderBossRecruit(data);
    renderJobAdvice(data);
    renderInvestment(data);
    renderSocialInsurance(data);
    renderStock(data);
    renderCulture(data);

    // 如果当前在欢迎页，自动切换到年报分析
    if (state.currentModule === 'welcome') {
      switchModule('annual-report');
    }
  }

  // ============================================================
  // 工具函数
  // ============================================================
  function destroyChart(id) {
    if (state.charts[id]) {
      state.charts[id].destroy();
      delete state.charts[id];
    }
  }

  function createChart(canvasId, config) {
    destroyChart(canvasId);
    const canvas = document.getElementById(canvasId);
    if (!canvas) return null;
    const ctx = canvas.getContext('2d');
    const chart = new Chart(ctx, config);
    state.charts[canvasId] = chart;
    return chart;
  }

  function formatNumber(num) {
    if (num >= 10000) return (num / 10000).toFixed(1) + '万';
    if (num >= 1000) return (num / 1000).toFixed(1) + 'k';
    return num.toString();
  }

  function staggerClass(index) {
    return `stagger-${Math.min(index + 1, 6)}`;
  }

  // ============================================================
  // 模块1: 年报分析
  // ============================================================
  function renderAnnualReport(data) {
    const d = data.annualReport;
    const info = data.basicInfo;
    const container = document.getElementById('annual-report-content');

    container.innerHTML = `
      <div class="card-grid card-grid-4 data-fade-in">
        <div class="stat-card ${staggerClass(0)}">
          <div class="stat-label">注册资本</div>
          <div class="stat-value blue">${info.registeredCapital}</div>
        </div>
        <div class="stat-card ${staggerClass(1)}">
          <div class="stat-label">成立日期</div>
          <div class="stat-value gold">${info.establishDate}</div>
        </div>
        <div class="stat-card ${staggerClass(2)}">
          <div class="stat-label">法定代表人</div>
          <div class="stat-value">${info.legalPerson}</div>
        </div>
        <div class="stat-card ${staggerClass(3)}">
          <div class="stat-label">员工人数</div>
          <div class="stat-value green">${formatNumber(info.employeeCount)}</div>
        </div>
      </div>

      <div class="card-grid card-grid-2 data-fade-in">
        <div class="card">
          <div class="card-title"><span class="card-title-icon">&#128202;</span> 公司基本信息</div>
          <ul class="info-list">
            <li class="info-item"><span class="info-label">公司名称</span><span class="info-value">${info.name}</span></li>
            <li class="info-item"><span class="info-label">所属行业</span><span class="info-value"><span class="tag tag-blue">${info.industry}</span></span></li>
            <li class="info-item"><span class="info-label">所在城市</span><span class="info-value">${info.city}</span></li>
            <li class="info-item"><span class="info-label">经营状态</span><span class="info-value"><span class="tag tag-green">${info.status}</span></span></li>
            <li class="info-item"><span class="info-label">注册地址</span><span class="info-value">${info.registeredAddress}</span></li>
          </ul>
        </div>
        <div class="card">
          <div class="card-title"><span class="card-title-icon">&#128176;</span> 关键财务指标</div>
          <div class="chart-container-sm">
            <canvas id="chart-financial-indicators"></canvas>
          </div>
        </div>
      </div>

      <div class="card data-fade-in">
        <div class="card-title"><span class="card-title-icon">&#128200;</span> 近5年营收/利润趋势（亿元）</div>
        <div class="chart-container">
          <canvas id="chart-revenue-profit"></canvas>
        </div>
      </div>

      <div class="card data-fade-in">
        <div class="card-title"><span class="card-title-icon">&#128196;</span> 年报摘要</div>
        <table class="data-table">
          <thead>
            <tr>
              <th>年份</th>
              <th>摘要内容</th>
            </tr>
          </thead>
          <tbody>
            ${d.summary.map(s => `
              <tr>
                <td><span class="tag tag-gold">${s.year}</span></td>
                <td>${s.summary}</td>
              </tr>
            `).join('')}
          </tbody>
        </table>
      </div>
    `;

    // 营收利润折线图
    createChart('chart-revenue-profit', {
      type: 'line',
      data: {
        labels: d.years,
        datasets: [
          {
            label: '营业收入（亿元）',
            data: d.revenue,
            borderColor: '#00d4ff',
            backgroundColor: 'rgba(0, 212, 255, 0.1)',
            fill: true,
            tension: 0.4,
            pointRadius: 5,
            pointHoverRadius: 8,
            borderWidth: 2
          },
          {
            label: '净利润（亿元）',
            data: d.profit,
            borderColor: '#f0b90b',
            backgroundColor: 'rgba(240, 185, 11, 0.1)',
            fill: true,
            tension: 0.4,
            pointRadius: 5,
            pointHoverRadius: 8,
            borderWidth: 2
          }
        ]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          tooltip: {
            callbacks: {
              label: function (ctx) {
                return ctx.dataset.label + ': ' + ctx.parsed.y + ' 亿元';
              }
            }
          }
        },
        scales: {
          y: {
            beginAtZero: true,
            grid: { color: 'rgba(42, 48, 80, 0.5)' }
          }
        }
      }
    });

    // 财务指标柱状图
    const fi = d.financialIndicators;
    createChart('chart-financial-indicators', {
      type: 'bar',
      data: {
        labels: ['毛利率%', '净利率%', 'ROE%', '负债率%', '流动比率', '速动比率'],
        datasets: [{
          label: '指标值',
          data: [fi.grossMargin, fi.netMargin, fi.roe, fi.debtRatio, fi.currentRatio * 20, fi.quickRatio * 20],
          backgroundColor: [
            'rgba(0, 212, 255, 0.7)',
            'rgba(240, 185, 11, 0.7)',
            'rgba(0, 230, 118, 0.7)',
            'rgba(255, 71, 87, 0.7)',
            'rgba(168, 85, 247, 0.7)',
            'rgba(255, 159, 67, 0.7)'
          ],
          borderColor: [
            '#00d4ff', '#f0b90b', '#00e676', '#ff4757', '#a855f7', '#ff9f43'
          ],
          borderWidth: 1,
          borderRadius: 4
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: { legend: { display: false } },
        scales: {
          y: {
            beginAtZero: true,
            grid: { color: 'rgba(42, 48, 80, 0.5)' }
          }
        }
      }
    });
  }

  // ============================================================
  // 模块2: 劳动仲裁
  // ============================================================
  function renderArbitration(data) {
    const d = data.arbitration;
    const container = document.getElementById('arbitration-content');

    container.innerHTML = `
      <div class="card-grid card-grid-3 data-fade-in">
        <div class="stat-card ${staggerClass(0)}">
          <div class="stat-label">仲裁案件总数</div>
          <div class="stat-value ${d.total > 20 ? 'red' : d.total > 10 ? 'gold' : 'green'}">${d.total}件</div>
          <div class="stat-change ${d.total > 20 ? 'down' : 'up'}">${d.total > 20 ? '风险较高' : d.total > 10 ? '需关注' : '风险较低'}</div>
        </div>
        <div class="stat-card ${staggerClass(1)}">
          <div class="stat-label">近3年趋势</div>
          <div class="stat-value">${d.trend[2] > d.trend[0] ? '上升' : '下降'}</div>
          <div class="stat-change ${d.trend[2] > d.trend[0] ? 'down' : 'up'}">${d.trend[2] > d.trend[0] ? '同比增加' : '同比减少'}</div>
        </div>
        <div class="stat-card ${staggerClass(2)}">
          <div class="stat-label">主要类型</div>
          <div class="stat-value" style="font-size:16px;">${Object.entries(d.types).sort((a, b) => b[1] - a[1])[0][0]}</div>
        </div>
      </div>

      <div class="card-grid card-grid-2 data-fade-in">
        <div class="card">
          <div class="card-title"><span class="card-title-icon">&#128203;</span> 案件类型分布</div>
          <div class="chart-container">
            <canvas id="chart-arbitration-types"></canvas>
          </div>
        </div>
        <div class="card">
          <div class="card-title"><span class="card-title-icon">&#128200;</span> 近3年仲裁趋势</div>
          <div class="chart-container">
            <canvas id="chart-arbitration-trend"></canvas>
          </div>
        </div>
      </div>

      <div class="card data-fade-in">
        <div class="card-title"><span class="card-title-icon">&#128221;</span> 典型案例</div>
        ${d.cases.length > 0 ? `
          <table class="data-table">
            <thead>
              <tr>
                <th>案号</th>
                <th>类型</th>
                <th>申请人</th>
                <th>结果</th>
                <th>金额</th>
                <th>日期</th>
              </tr>
            </thead>
            <tbody>
              ${d.cases.map(c => `
                <tr>
                  <td style="font-size:12px;">${c.caseNo}</td>
                  <td><span class="tag tag-orange">${c.type}</span></td>
                  <td>${c.applicant}</td>
                  <td><span class="tag ${c.result === '裁决支持' ? 'tag-red' : c.result === '调解成功' ? 'tag-green' : 'tag-blue'}">${c.result}</span></td>
                  <td class="text-right">${c.amount}</td>
                  <td>${c.date}</td>
                </tr>
              `).join('')}
            </tbody>
          </table>
        ` : '<div class="empty-state"><div class="empty-state-text">暂无仲裁记录</div></div>'}
      </div>
    `;

    // 案件类型饼图
    const typeLabels = Object.keys(d.types);
    const typeValues = Object.values(d.types);
    const pieColors = ['#00d4ff', '#f0b90b', '#00e676', '#ff4757', '#a855f7', '#ff9f43'];

    createChart('chart-arbitration-types', {
      type: 'doughnut',
      data: {
        labels: typeLabels,
        datasets: [{
          data: typeValues,
          backgroundColor: pieColors.slice(0, typeLabels.length),
          borderColor: '#1a1f35',
          borderWidth: 2
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: {
            position: 'right'
          }
        }
      }
    });

    // 仲裁趋势折线图
    createChart('chart-arbitration-trend', {
      type: 'line',
      data: {
        labels: d.trendYears,
        datasets: [{
          label: '仲裁案件数',
          data: d.trend,
          borderColor: '#ff4757',
          backgroundColor: 'rgba(255, 71, 87, 0.1)',
          fill: true,
          tension: 0.4,
          pointRadius: 6,
          pointHoverRadius: 9,
          borderWidth: 2,
          pointBackgroundColor: '#ff4757'
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: { legend: { display: false } },
        scales: {
          y: {
            beginAtZero: true,
            grid: { color: 'rgba(42, 48, 80, 0.5)' }
          }
        }
      }
    });
  }

  // ============================================================
  // 模块3: 司法判决
  // ============================================================
  function renderLawsuit(data) {
    const d = data.lawsuit;
    const container = document.getElementById('lawsuit-content');

    container.innerHTML = `
      <div class="card-grid card-grid-3 data-fade-in">
        <div class="stat-card ${staggerClass(0)}">
          <div class="stat-label">涉诉案件总数</div>
          <div class="stat-value blue">${d.total}件</div>
        </div>
        <div class="stat-card ${staggerClass(1)}">
          <div class="stat-label">作为原告比例</div>
          <div class="stat-value green">${(d.plaintiffRatio * 100).toFixed(1)}%</div>
        </div>
        <div class="stat-card ${staggerClass(2)}">
          <div class="stat-label">作为被告比例</div>
          <div class="stat-value red">${(d.defendantRatio * 100).toFixed(1)}%</div>
        </div>
      </div>

      <div class="card-grid card-grid-2 data-fade-in">
        <div class="card">
          <div class="card-title"><span class="card-title-icon">&#128202;</span> 案件类型分布</div>
          <div class="chart-container">
            <canvas id="chart-lawsuit-types"></canvas>
          </div>
        </div>
        <div class="card">
          <div class="card-title"><span class="card-title-icon">&#128200;</span> 原告/被告比例</div>
          <div class="chart-container">
            <canvas id="chart-lawsuit-role"></canvas>
          </div>
        </div>
      </div>

      <div class="card data-fade-in">
        <div class="card-title"><span class="card-title-icon">&#128221;</span> 重要判决文书</div>
        <table class="data-table">
          <thead>
            <tr>
              <th>案号</th>
              <th>类型</th>
              <th>角色</th>
              <th>对方当事人</th>
              <th>结果</th>
              <th>日期</th>
            </tr>
          </thead>
          <tbody>
            ${d.cases.map(c => `
              <tr>
                <td style="font-size:12px;">${c.caseNo}</td>
                <td><span class="tag tag-purple">${c.type}</span></td>
                <td><span class="tag ${c.role === '原告' ? 'tag-green' : 'tag-red'}">${c.role}</span></td>
                <td>${c.opponent}</td>
                <td><span class="tag ${c.result === '胜诉' ? 'tag-green' : c.result === '败诉' ? 'tag-red' : 'tag-gold'}">${c.result}</span></td>
                <td>${c.date}</td>
              </tr>
            `).join('')}
          </tbody>
        </table>
      </div>
    `;

    // 案件类型柱状图
    createChart('chart-lawsuit-types', {
      type: 'bar',
      data: {
        labels: Object.keys(d.types),
        datasets: [{
          label: '案件数量',
          data: Object.values(d.types),
          backgroundColor: [
            'rgba(0, 212, 255, 0.7)',
            'rgba(240, 185, 11, 0.7)',
            'rgba(0, 230, 118, 0.7)',
            'rgba(255, 71, 87, 0.7)',
            'rgba(168, 85, 247, 0.7)',
            'rgba(255, 159, 67, 0.7)'
          ],
          borderColor: ['#00d4ff', '#f0b90b', '#00e676', '#ff4757', '#a855f7', '#ff9f43'],
          borderWidth: 1,
          borderRadius: 4
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        indexAxis: 'y',
        plugins: { legend: { display: false } },
        scales: {
          x: {
            beginAtZero: true,
            grid: { color: 'rgba(42, 48, 80, 0.5)' }
          }
        }
      }
    });

    // 原告/被告环形图
    createChart('chart-lawsuit-role', {
      type: 'doughnut',
      data: {
        labels: ['原告', '被告'],
        datasets: [{
          data: [d.plaintiffRatio * 100, d.defendantRatio * 100],
          backgroundColor: ['rgba(0, 230, 118, 0.8)', 'rgba(255, 71, 87, 0.8)'],
          borderColor: '#1a1f35',
          borderWidth: 3
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        cutout: '60%',
        plugins: {
          legend: { position: 'bottom' },
          tooltip: {
            callbacks: {
              label: function (ctx) {
                return ctx.label + ': ' + ctx.parsed.toFixed(1) + '%';
              }
            }
          }
        }
      }
    });
  }

  // ============================================================
  // 模块4: 加班及员工评价
  // ============================================================
  function renderOvertime(data) {
    const d = data.overtime;
    const container = document.getElementById('overtime-content');

    container.innerHTML = `
      <div class="card-grid card-grid-3 data-fade-in">
        <div class="stat-card ${staggerClass(0)}">
          <div class="stat-label">员工满意度</div>
          <div class="stat-value gold">${d.satisfactionScore}<span style="font-size:14px;color:var(--text-muted);">/5.0</span></div>
          <div class="stat-change up">共 ${d.satisfactionTotal} 条评价</div>
        </div>
        <div class="stat-card ${staggerClass(1)}">
          <div class="stat-label">加班指数</div>
          <div class="stat-value ${parseFloat(d.scores.overtimeFrequency) > 7 ? 'red' : 'green'}">${d.scores.overtimeFrequency}/10</div>
          <div class="stat-change ${parseFloat(d.scores.overtimeFrequency) > 7 ? 'down' : 'up'}">${parseFloat(d.scores.overtimeFrequency) > 7 ? '加班频繁' : '加班适中'}</div>
        </div>
        <div class="stat-card ${staggerClass(2)}">
          <div class="stat-label">工作生活平衡</div>
          <div class="stat-value">${d.scores.workLifeBalance}/10</div>
        </div>
      </div>

      <div class="card-grid card-grid-2 data-fade-in">
        <div class="card">
          <div class="card-title"><span class="card-title-icon">&#128202;</span> 加班指数评分（雷达图）</div>
          <div class="chart-container">
            <canvas id="chart-overtime-radar"></canvas>
          </div>
        </div>
        <div class="card">
          <div class="card-title"><span class="card-title-icon">&#127991;</span> 员工评价标签云</div>
          <div class="tag-cloud">
            ${d.tagCloud.map(t => `
              <span class="tag ${t.positive ? 'tag-green' : 'tag-red'}" style="font-size:${Math.max(12, t.weight / 10)}px;">${t.text}</span>
            `).join('')}
          </div>
          <div style="margin-top:16px;">
            <div style="display:flex;justify-content:space-between;font-size:12px;color:var(--text-muted);">
              <span>&#128154; 正面评价</span>
              <span>&#128148; 负面评价</span>
            </div>
          </div>
        </div>
      </div>

      <div class="card data-fade-in">
        <div class="card-title"><span class="card-title-icon">&#128172;</span> 员工评价</div>
        ${d.reviews.map(r => `
          <div class="review-card">
            <div class="review-header">
              <div class="review-meta">
                <span>${r.position}</span>
                <span>${r.date}</span>
              </div>
              <div class="review-rating ${r.sentiment}">
                ${'&#9733;'.repeat(Math.round(r.rating))}${'&#9734;'.repeat(5 - Math.round(r.rating))}
                <span style="margin-left:4px;">${r.rating}</span>
              </div>
            </div>
            <div class="review-text">${r.text}</div>
          </div>
        `).join('')}
      </div>
    `;

    // 加班指数雷达图
    const scores = d.scores;
    createChart('chart-overtime-radar', {
      type: 'radar',
      data: {
        labels: ['工作强度', '加班频率', '周末加班', '加班补偿', '工作生活平衡'],
        datasets: [{
          label: '评分',
          data: [scores.workIntensity, scores.overtimeFrequency, scores.weekendOvertime, scores.overtimeCompensation, scores.workLifeBalance],
          backgroundColor: 'rgba(0, 212, 255, 0.2)',
          borderColor: '#00d4ff',
          pointBackgroundColor: '#00d4ff',
          pointBorderColor: '#fff',
          pointHoverBackgroundColor: '#fff',
          pointHoverBorderColor: '#00d4ff',
          borderWidth: 2,
          pointRadius: 5
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: { legend: { display: false } },
        scales: {
          r: {
            beginAtZero: true,
            max: 10,
            ticks: {
              stepSize: 2,
              color: '#6b7280',
              backdropColor: 'transparent'
            },
            grid: { color: 'rgba(42, 48, 80, 0.5)' },
            pointLabels: { color: '#9ca3af', font: { size: 13 } },
            angleLines: { color: 'rgba(42, 48, 80, 0.5)' }
          }
        }
      }
    });
  }

  // ============================================================
  // 模块5: BOSS直聘活跃度
  // ============================================================
  function renderBossRecruit(data) {
    const d = data.bossRecruit;
    const container = document.getElementById('boss-recruit-content');

    container.innerHTML = `
      <div class="card-grid card-grid-3 data-fade-in">
        <div class="stat-card ${staggerClass(0)}">
          <div class="stat-label">在招职位数量</div>
          <div class="stat-value blue">${d.jobCount}个</div>
        </div>
        <div class="stat-card ${staggerClass(1)}">
          <div class="stat-label">活跃度评分</div>
          <div class="stat-value ${d.activityScore > 80 ? 'green' : d.activityScore > 50 ? 'gold' : 'red'}">${d.activityScore}</div>
          <div class="stat-change up">满分100</div>
        </div>
        <div class="stat-card ${staggerClass(2)}">
          <div class="stat-label">主要招聘类型</div>
          <div class="stat-value" style="font-size:16px;">${Object.entries(d.jobTypes).sort((a, b) => b[1] - a[1])[0][0]}</div>
        </div>
      </div>

      <div class="card-grid card-grid-2 data-fade-in">
        <div class="card">
          <div class="card-title"><span class="card-title-icon">&#127919;</span> 活跃度仪表盘</div>
          <div class="gauge-container">
            <div class="chart-container-sm">
              <canvas id="chart-boss-gauge"></canvas>
            </div>
          </div>
        </div>
        <div class="card">
          <div class="card-title"><span class="card-title-icon">&#128202;</span> 职位类型分布</div>
          <div class="chart-container">
            <canvas id="chart-job-types"></canvas>
          </div>
        </div>
      </div>

      <div class="card data-fade-in">
        <div class="card-title"><span class="card-title-icon">&#128200;</span> 近6个月招聘趋势</div>
        <div class="chart-container">
          <canvas id="chart-recruit-trend"></canvas>
        </div>
      </div>
    `;

    // 活跃度仪表盘（用环形图模拟）
    const gaugeColor = d.activityScore > 80 ? '#00e676' : d.activityScore > 50 ? '#f0b90b' : '#ff4757';
    createChart('chart-boss-gauge', {
      type: 'doughnut',
      data: {
        labels: ['活跃度', '剩余'],
        datasets: [{
          data: [d.activityScore, 100 - d.activityScore],
          backgroundColor: [gaugeColor, 'rgba(42, 48, 80, 0.5)'],
          borderColor: '#1a1f35',
          borderWidth: 3
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        cutout: '75%',
        rotation: -90,
        circumference: 180,
        plugins: {
          legend: { display: false },
          tooltip: { enabled: false }
        }
      }
    });

    // 职位类型分布
    const jobColors = ['#00d4ff', '#f0b90b', '#00e676', '#ff4757', '#a855f7', '#ff9f43'];
    createChart('chart-job-types', {
      type: 'doughnut',
      data: {
        labels: Object.keys(d.jobTypes),
        datasets: [{
          data: Object.values(d.jobTypes),
          backgroundColor: jobColors,
          borderColor: '#1a1f35',
          borderWidth: 2
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: { position: 'right' }
        }
      }
    });

    // 招聘趋势
    createChart('chart-recruit-trend', {
      type: 'bar',
      data: {
        labels: d.recruitMonths,
        datasets: [{
          label: '在招职位数',
          data: d.recruitTrend,
          backgroundColor: 'rgba(0, 212, 255, 0.6)',
          borderColor: '#00d4ff',
          borderWidth: 1,
          borderRadius: 6
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: { legend: { display: false } },
        scales: {
          y: {
            beginAtZero: true,
            grid: { color: 'rgba(42, 48, 80, 0.5)' }
          }
        }
      }
    });
  }

  // ============================================================
  // 模块6: 求职建议
  // ============================================================
  function renderJobAdvice(data) {
    const d = data.jobAdvice;
    const container = document.getElementById('job-advice-content');

    container.innerHTML = `
      <div class="score-display data-fade-in">
        <div class="score-circle" style="border-color:${d.riskColor};">
          <div class="score-number" style="color:${d.riskColor};">${d.overallScore}</div>
          <div class="score-unit">分</div>
        </div>
        <div class="score-info">
          <div class="score-risk" style="background:${d.riskColor}22;color:${d.riskColor};">
            风险等级：${d.riskLevel}
          </div>
          <div class="score-desc">
            综合分析${state.currentCompany}的财务状况、法律风险、员工评价、招聘活跃度等多维度数据，
            给出综合评分 ${d.overallScore} 分（满分100分）。
            ${d.overallScore >= 75 ? '该公司整体表现优秀，值得考虑加入。' :
              d.overallScore >= 50 ? '该公司存在一些需要注意的问题，建议深入了解后再做决定。' :
                '该公司存在较多风险因素，建议谨慎考虑。'}
          </div>
        </div>
      </div>

      <div class="analysis-grid data-fade-in">
        <div class="analysis-card advantages">
          <h3><span style="color:var(--accent-green);">&#10003;</span> 优势分析</h3>
          <ul class="analysis-list">
            ${d.advantages.map(a => `<li>${a}</li>`).join('')}
          </ul>
        </div>
        <div class="analysis-card disadvantages">
          <h3><span style="color:var(--accent-red);">&#10007;</span> 劣势分析</h3>
          <ul class="analysis-list">
            ${d.disadvantages.map(d => `<li>${d}</li>`).join('')}
          </ul>
        </div>
      </div>

      <div class="card data-fade-in" style="margin-bottom:24px;">
        <div class="card-title"><span class="card-title-icon">&#128161;</span> 具体建议</div>
        <ul class="suggestion-list">
          ${d.suggestions.map((s, i) => `
            <li>
              <span class="suggestion-num">${i + 1}</span>
              <span>${s}</span>
            </li>
          `).join('')}
        </ul>
      </div>

      <div class="card data-fade-in">
        <div class="card-title"><span class="card-title-icon">&#9989;</span> 入职前检查清单</div>
        <ul class="checklist" id="checklist">
          ${d.checklist.map((c, i) => `
            <li data-index="${i}">
              <span class="check-box"></span>
              <span>${c.item}</span>
            </li>
          `).join('')}
        </ul>
      </div>
    `;

    // 绑定检查清单事件
    document.getElementById('checklist').addEventListener('click', function (e) {
      const li = e.target.closest('li');
      if (li) {
        li.classList.toggle('checked');
      }
    });
  }

  // ============================================================
  // 模块7: 投资情况
  // ============================================================
  function renderInvestment(data) {
    const d = data.investment;
    const container = document.getElementById('investment-content');

    container.innerHTML = `
      <div class="card-grid card-grid-3 data-fade-in">
        <div class="stat-card ${staggerClass(0)}">
          <div class="stat-label">融资总额</div>
          <div class="stat-value blue">${d.externalInvestment.totalAmount}</div>
        </div>
        <div class="stat-card ${staggerClass(1)}">
          <div class="stat-label">投资方数量</div>
          <div class="stat-value gold">${d.externalInvestment.investorCount}家</div>
        </div>
        <div class="stat-card ${staggerClass(2)}">
          <div class="stat-label">最新估值</div>
          <div class="stat-value green">${d.externalInvestment.latestValuation}</div>
        </div>
      </div>

      <div class="card-grid card-grid-2 data-fade-in">
        <div class="card">
          <div class="card-title"><span class="card-title-icon">&#128197;</span> 投资事件时间线</div>
          <div class="timeline">
            ${d.events.map(e => `
              <div class="timeline-item">
                <div class="timeline-date">${e.date}</div>
                <div class="timeline-content">
                  <div class="timeline-round">
                    <span class="tag tag-blue">${e.round}</span>
                    <span style="margin-left:8px;color:var(--accent-gold);font-weight:600;">${e.amount}</span>
                  </div>
                  <div class="timeline-detail">
                    估值：${e.valuation}
                    <div class="timeline-investors">
                      ${e.investors.map(inv => `<span class="tag tag-purple">${inv}</span>`).join('')}
                    </div>
                  </div>
                </div>
              </div>
            `).join('')}
          </div>
        </div>
        <div class="card">
          <div class="card-title"><span class="card-title-icon">&#128202;</span> 投资轮次分布</div>
          <div class="chart-container">
            <canvas id="chart-invest-rounds"></canvas>
          </div>
        </div>
      </div>

      <div class="card data-fade-in">
        <div class="card-title"><span class="card-title-icon">&#127760;</span> 被投企业列表</div>
        ${d.portfolioCompanies.map(pc => `
          <div class="portfolio-item">
            <div>
              <div class="portfolio-name">${pc.name}</div>
              <div style="font-size:12px;color:var(--text-muted);margin-top:2px;">${pc.industry}</div>
            </div>
            <div class="portfolio-detail">
              <div>投资额：${pc.investAmount}</div>
              <div>持股：${pc.shareRatio} | <span class="tag ${pc.status === '已退出' ? 'tag-gold' : pc.status === 'IPO中' ? 'tag-green' : 'tag-blue'}">${pc.status}</span></div>
            </div>
          </div>
        `).join('')}
      </div>
    `;

    // 投资轮次分布
    const roundLabels = Object.keys(d.roundDist);
    const roundValues = Object.values(d.roundDist);
    const roundColors = ['#00d4ff', '#f0b90b', '#00e676', '#ff4757', '#a855f7', '#ff9f43', '#e91e63', '#00bcd4', '#8bc34a'];

    createChart('chart-invest-rounds', {
      type: 'bar',
      data: {
        labels: roundLabels,
        datasets: [{
          label: '轮次',
          data: roundValues,
          backgroundColor: roundColors.slice(0, roundLabels.length).map(c => c + 'bb'),
          borderColor: roundColors.slice(0, roundLabels.length),
          borderWidth: 1,
          borderRadius: 6
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: { legend: { display: false } },
        scales: {
          y: {
            beginAtZero: true,
            ticks: { stepSize: 1 },
            grid: { color: 'rgba(42, 48, 80, 0.5)' }
          }
        }
      }
    });
  }

  // ============================================================
  // 模块8: 社保缴纳
  // ============================================================
  function renderSocialInsurance(data) {
    const d = data.socialInsurance;
    const container = document.getElementById('social-insurance-content');

    const ratio = d.actualVsExpected;
    const ratioPercent = (ratio.actual / ratio.expected * 100).toFixed(1);

    container.innerHTML = `
      <div class="card-grid card-grid-3 data-fade-in">
        <div class="stat-card ${staggerClass(0)}">
          <div class="stat-label">实际缴纳人数</div>
          <div class="stat-value blue">${formatNumber(ratio.actual)}</div>
        </div>
        <div class="stat-card ${staggerClass(1)}">
          <div class="stat-label">应缴纳人数</div>
          <div class="stat-value gold">${formatNumber(ratio.expected)}</div>
        </div>
        <div class="stat-card ${staggerClass(2)}">
          <div class="stat-label">缴纳率</div>
          <div class="stat-value ${parseFloat(ratioPercent) > 90 ? 'green' : parseFloat(ratioPercent) > 75 ? 'gold' : 'red'}">${ratioPercent}%</div>
        </div>
      </div>

      <div class="card-grid card-grid-2 data-fade-in">
        <div class="card">
          <div class="card-title"><span class="card-title-icon">&#128200;</span> 缴纳人数趋势</div>
          <div class="chart-container">
            <canvas id="chart-si-trend"></canvas>
          </div>
        </div>
        <div class="card">
          <div class="card-title"><span class="card-title-icon">&#128202;</span> 五险一金缴纳比例</div>
          <div class="chart-container">
            <canvas id="chart-si-ratios"></canvas>
          </div>
        </div>
      </div>

      <div class="card-grid card-grid-2 data-fade-in">
        <div class="card">
          <div class="card-title"><span class="card-title-icon">&#9878;</span> 实际 vs 应缴纳人数对比</div>
          <div class="chart-container">
            <canvas id="chart-si-compare"></canvas>
          </div>
        </div>
        <div class="card">
          <div class="card-title"><span class="card-title-icon">&#127760;</span> 同行业对比</div>
          <div class="chart-container">
            <canvas id="chart-si-industry"></canvas>
          </div>
        </div>
      </div>
    `;

    // 缴纳人数趋势
    createChart('chart-si-trend', {
      type: 'line',
      data: {
        labels: d.trendYears,
        datasets: [{
          label: '缴纳人数',
          data: d.trend,
          borderColor: '#00d4ff',
          backgroundColor: 'rgba(0, 212, 255, 0.1)',
          fill: true,
          tension: 0.4,
          pointRadius: 5,
          borderWidth: 2
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: { legend: { display: false } },
        scales: {
          y: {
            beginAtZero: false,
            grid: { color: 'rgba(42, 48, 80, 0.5)' }
          }
        }
      }
    });

    // 五险一金缴纳比例
    const siLabels = Object.keys(d.ratios);
    const siValues = Object.values(d.ratios);
    const siColors = ['#00d4ff', '#f0b90b', '#00e676', '#ff4757', '#a855f7', '#ff9f43'];

    createChart('chart-si-ratios', {
      type: 'bar',
      data: {
        labels: siLabels,
        datasets: [{
          label: '缴纳比例(%)',
          data: siValues,
          backgroundColor: siColors.map(c => c + '99'),
          borderColor: siColors,
          borderWidth: 1,
          borderRadius: 4
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: { legend: { display: false } },
        scales: {
          y: {
            min: 60,
            max: 100,
            grid: { color: 'rgba(42, 48, 80, 0.5)' },
            ticks: {
              callback: function (v) { return v + '%'; }
            }
          }
        }
      }
    });

    // 实际vs应缴纳
    createChart('chart-si-compare', {
      type: 'bar',
      data: {
        labels: ['实际缴纳', '应缴纳'],
        datasets: [{
          label: '人数',
          data: [ratio.actual, ratio.expected],
          backgroundColor: ['rgba(0, 212, 255, 0.7)', 'rgba(240, 185, 11, 0.7)'],
          borderColor: ['#00d4ff', '#f0b90b'],
          borderWidth: 1,
          borderRadius: 6,
          barPercentage: 0.5
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: { legend: { display: false } },
        scales: {
          y: {
            beginAtZero: true,
            grid: { color: 'rgba(42, 48, 80, 0.5)' }
          }
        }
      }
    });

    // 行业对比
    const ic = d.industryCompare;
    createChart('chart-si-industry', {
      type: 'bar',
      data: {
        labels: [ic.companyName, '行业平均', '行业标杆'],
        datasets: [{
          label: '缴纳率(%)',
          data: [ic.pensionRate, ic.industryAvg, ic.industryTop],
          backgroundColor: ['rgba(0, 212, 255, 0.8)', 'rgba(240, 185, 11, 0.8)', 'rgba(0, 230, 118, 0.8)'],
          borderColor: ['#00d4ff', '#f0b90b', '#00e676'],
          borderWidth: 1,
          borderRadius: 6,
          barPercentage: 0.5
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: { legend: { display: false } },
        scales: {
          y: {
            min: 60,
            max: 100,
            grid: { color: 'rgba(42, 48, 80, 0.5)' },
            ticks: {
              callback: function (v) { return v + '%'; }
            }
          }
        }
      }
    });
  }

  // ============================================================
  // 模块9: 股票投资
  // ============================================================
  function renderStock(data) {
    const d = data.stock;
    const container = document.getElementById('stock-content');

    if (d.markets.length === 0) {
      container.innerHTML = `
        <div class="card data-fade-in">
          <div class="empty-state">
            <div class="empty-state-icon">&#128202;</div>
            <div class="empty-state-text">该公司暂无公开上市信息</div>
          </div>
        </div>
      `;
      return;
    }

    container.innerHTML = `
      <div class="card-grid card-grid-${Math.min(d.markets.length, 3)} data-fade-in">
        ${d.markets.map(m => `
          <div class="stock-card">
            <div class="stock-header">
              <div>
                <div class="stock-name">${m.market}</div>
                <div class="stock-code">${m.code}</div>
              </div>
              <div class="stock-change ${m.change >= 0 ? 'up' : 'down'}">
                ${m.change >= 0 ? '+' : ''}${m.change}%
              </div>
            </div>
            <div class="stock-price" style="color:${m.change >= 0 ? 'var(--accent-green)' : 'var(--accent-red)'};">
              ${m.currentPrice}
            </div>
            <div class="stock-meta">
              <span>市值：${m.marketCap}</span>
            </div>
          </div>
        `).join('')}
      </div>

      <div class="card data-fade-in">
        <div class="card-title"><span class="card-title-icon">&#128200;</span> 股价走势（近12个月）</div>
        <div class="chart-container-lg">
          <canvas id="chart-stock-price"></canvas>
        </div>
      </div>

      <div class="card data-fade-in">
        <div class="card-title"><span class="card-title-icon">&#128176;</span> 关键财务指标</div>
        <div class="card-grid card-grid-3" style="margin-top:16px;">
          <div class="stat-card">
            <div class="stat-label">市盈率(PE)</div>
            <div class="stat-value blue">${d.financials.pe}</div>
          </div>
          <div class="stat-card">
            <div class="stat-label">市净率(PB)</div>
            <div class="stat-value gold">${d.financials.pb}</div>
          </div>
          <div class="stat-card">
            <div class="stat-label">每股收益(EPS)</div>
            <div class="stat-value green">${d.financials.eps}</div>
          </div>
          <div class="stat-card">
            <div class="stat-label">股息率</div>
            <div class="stat-value">${d.financials.dividendYield}%</div>
          </div>
          <div class="stat-card">
            <div class="stat-label">营收增长率</div>
            <div class="stat-value ${d.financials.revenueGrowth >= 0 ? 'green' : 'red'}">${d.financials.revenueGrowth >= 0 ? '+' : ''}${d.financials.revenueGrowth}%</div>
          </div>
          <div class="stat-card">
            <div class="stat-label">利润增长率</div>
            <div class="stat-value ${d.financials.profitGrowth >= 0 ? 'green' : 'red'}">${d.financials.profitGrowth >= 0 ? '+' : ''}${d.financials.profitGrowth}%</div>
          </div>
        </div>
      </div>
    `;

    // 股价走势图
    createChart('chart-stock-price', {
      type: 'line',
      data: {
        labels: d.priceMonths,
        datasets: [{
          label: '股价',
          data: d.priceTrend,
          borderColor: '#00d4ff',
          backgroundColor: function (context) {
            const chart = context.chart;
            const { ctx, chartArea } = chart;
            if (!chartArea) return 'rgba(0, 212, 255, 0.1)';
            const gradient = ctx.createLinearGradient(0, chartArea.top, 0, chartArea.bottom);
            gradient.addColorStop(0, 'rgba(0, 212, 255, 0.3)');
            gradient.addColorStop(1, 'rgba(0, 212, 255, 0.0)');
            return gradient;
          },
          fill: true,
          tension: 0.4,
          pointRadius: 4,
          pointHoverRadius: 7,
          borderWidth: 2,
          pointBackgroundColor: '#00d4ff'
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: { legend: { display: false } },
        scales: {
          y: {
            grid: { color: 'rgba(42, 48, 80, 0.5)' }
          }
        }
      }
    });
  }

  // ============================================================
  // 模块10: 企业文化
  // ============================================================
  function renderCulture(data) {
    const d = data.culture;
    const container = document.getElementById('culture-content');

    container.innerHTML = `
      <div class="card-grid card-grid-2 data-fade-in">
        <div class="card">
          <div class="card-title"><span class="card-title-icon">&#128202;</span> 文化维度评分</div>
          <div class="chart-container">
            <canvas id="chart-culture-radar"></canvas>
          </div>
        </div>
        <div class="card">
          <div class="card-title"><span class="card-title-icon">&#127991;</span> 文化标签</div>
          <div class="tag-cloud" style="margin-top:16px;">
            ${d.tags.map(t => `<span class="tag tag-blue">${t}</span>`).join('')}
          </div>
          <div class="divider"></div>
          <div class="card-title"><span class="card-title-icon">&#127873;</span> 福利待遇</div>
          <div class="benefit-grid">
            ${d.benefits.map(b => `
              <div class="benefit-item">
                <span class="benefit-icon">&#10003;</span>
                <span>${b}</span>
              </div>
            `).join('')}
          </div>
        </div>
      </div>

      <div class="card data-fade-in">
        <div class="card-title"><span class="card-title-icon">&#127891;</span> 员工活动与培训</div>
        ${d.activities.map(a => `
          <div class="activity-card">
            <span class="activity-type ${a.type === '培训' ? 'training' : 'event'}">${a.type}</span>
            <div class="activity-info">
              <div class="activity-name">${a.name}</div>
              <div class="activity-desc">${a.desc}</div>
              <div class="activity-freq">频率：${a.frequency}</div>
            </div>
          </div>
        `).join('')}
      </div>
    `;

    // 文化维度雷达图
    const cs = d.scores;
    createChart('chart-culture-radar', {
      type: 'radar',
      data: {
        labels: ['创新力', '协作性', '透明度', '员工关怀', '成长空间'],
        datasets: [{
          label: '评分',
          data: [cs.innovation, cs.collaboration, cs.transparency, cs.employeeCare, cs.growthSpace],
          backgroundColor: 'rgba(240, 185, 11, 0.2)',
          borderColor: '#f0b90b',
          pointBackgroundColor: '#f0b90b',
          pointBorderColor: '#fff',
          pointHoverBackgroundColor: '#fff',
          pointHoverBorderColor: '#f0b90b',
          borderWidth: 2,
          pointRadius: 5
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: { legend: { display: false } },
        scales: {
          r: {
            beginAtZero: true,
            max: 10,
            ticks: {
              stepSize: 2,
              color: '#6b7280',
              backdropColor: 'transparent'
            },
            grid: { color: 'rgba(42, 48, 80, 0.5)' },
            pointLabels: { color: '#9ca3af', font: { size: 13 } },
            angleLines: { color: 'rgba(42, 48, 80, 0.5)' }
          }
        }
      }
    });
  }

  // ============================================================
  // 启动
  // ============================================================
  document.addEventListener('DOMContentLoaded', init);

})();
