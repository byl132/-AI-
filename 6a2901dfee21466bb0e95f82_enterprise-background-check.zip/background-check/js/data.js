// ============================================================
// 企业背调小程序 - 模拟数据
// ============================================================

const MockData = {
  // 支持搜索的公司列表
  companyList: [
    '字节跳动', '阿里巴巴', '腾讯控股', '华为技术', '百度集团',
    '京东集团', '美团', '拼多多', '小米集团', '网易', '快手科技',
    '滴滴出行', '蚂蚁集团', '商汤科技', '大疆创新', '比亚迪',
    '宁德时代', '中芯国际', '科大讯飞', '海康威视'
  ],

  // 根据公司名称生成数据（使用确定性伪随机）
  generateCompanyData(name) {
    const seed = this._hashStr(name);
    const rand = (min, max) => {
      const x = Math.sin(seed + arguments.callee.caller.arguments[0] * 9301 + 49297) * 49297;
      return min + (x - Math.floor(x)) * (max - min);
    };
    // 简单的种子随机
    let _s = seed;
    const seededRand = (min, max) => {
      _s = (_s * 9301 + 49297) % 233280;
      return min + (_s / 233280) * (max - min);
    };
    const sRand = seededRand;

    const industries = ['互联网/科技', '电子商务', '人工智能', '智能制造', '新能源', '半导体', '软件开发', '金融科技', '企业服务', '消费电子'];
    const cities = ['北京', '上海', '深圳', '杭州', '广州', '南京', '成都', '武汉', '苏州', '东莞'];
    const legalPersons = ['张三', '李四', '王五', '赵六', '陈七', '刘八', '杨九', '黄十', '周明', '吴强'];
    const statuses = ['存续', '在营', '正常'];

    const industry = industries[Math.floor(sRand(0, industries.length))];
    const city = cities[Math.floor(sRand(0, cities.length))];
    const legalPerson = legalPersons[Math.floor(sRand(0, legalPersons.length))];
    const status = statuses[Math.floor(sRand(0, statuses.length))];

    const registeredCapital = Math.floor(sRand(500, 500000));
    const capitalUnit = registeredCapital > 10000 ? '万元人民币' : '万元人民币';
    const establishYear = 2000 + Math.floor(sRand(0, 24));
    const establishMonth = Math.floor(sRand(1, 13));
    const establishDate = `${establishYear}-${String(establishMonth).padStart(2, '0')}-01`;
    const employeeCount = Math.floor(sRand(500, 150000));

    // 模块1: 年报分析
    const revenue = [];
    const profit = [];
    for (let i = 0; i < 5; i++) {
      const r = Math.floor(sRand(10, 5000));
      const p = Math.floor(r * sRand(0.05, 0.25));
      revenue.push(r);
      profit.push(p);
    }
    const years = [];
    for (let i = 4; i >= 0; i--) {
      years.push(2024 - i);
    }

    const financialIndicators = {
      grossMargin: +(sRand(15, 65)).toFixed(1),
      netMargin: +(sRand(3, 25)).toFixed(1),
      roe: +(sRand(5, 30)).toFixed(1),
      debtRatio: +(sRand(20, 70)).toFixed(1),
      currentRatio: +(sRand(1.0, 3.5)).toFixed(2),
      quickRatio: +(sRand(0.8, 3.0)).toFixed(2)
    };

    const annualReportSummary = [
      { year: 2024, summary: `${name}2024年度营业收入达到${revenue[4]}亿元，同比增长${(sRand(5, 35)).toFixed(1)}%，净利润${profit[4]}亿元。公司持续加大研发投入，研发费用占营收比例达${(sRand(8, 25)).toFixed(1)}%。` },
      { year: 2023, summary: `${name}2023年度实现营收${revenue[3]}亿元，净利润${profit[3]}亿元。公司业务稳步扩张，新开拓了${Math.floor(sRand(2, 8))}个海外市场。` },
      { year: 2022, summary: `${name}2022年度营收${revenue[2]}亿元，净利润${profit[2]}亿元。受宏观经济影响，增速有所放缓，但核心业务保持韧性。` },
      { year: 2021, summary: `${name}2021年度营收${revenue[1]}亿元，净利润${profit[1]}亿元。公司完成新一轮融资，估值大幅提升。` },
      { year: 2020, summary: `${name}2020年度营收${revenue[0]}亿元，净利润${profit[0]}亿元。面对疫情挑战，公司积极转型线上业务，实现逆势增长。` }
    ];

    // 模块2: 劳动仲裁
    const arbitrationTotal = Math.floor(sRand(0, 50));
    const arbitrationTypes = {
      '工资拖欠': Math.floor(sRand(0, 15)),
      '违法解除': Math.floor(sRand(0, 12)),
      '工伤赔偿': Math.floor(sRand(0, 10)),
      '加班费争议': Math.floor(sRand(0, 10)),
      '社保纠纷': Math.floor(sRand(0, 8)),
      '竞业限制': Math.floor(sRand(0, 5))
    };
    const arbitrationTrend = [
      Math.floor(sRand(1, 20)),
      Math.floor(sRand(1, 20)),
      Math.floor(sRand(1, 20))
    ];

    const arbitrationCases = [];
    const caseTypes = ['工资拖欠', '违法解除', '工伤赔偿', '加班费争议', '社保纠纷'];
    const caseResults = ['调解成功', '裁决支持', '部分支持', '驳回'];
    for (let i = 0; i < Math.min(arbitrationTotal, 6); i++) {
      arbitrationCases.push({
        caseNo: `劳仲案字[${2022 + Math.floor(sRand(0, 3))}]第${Math.floor(sRand(100, 999))}号`,
        type: caseTypes[Math.floor(sRand(0, caseTypes.length))],
        applicant: `员工${String.fromCharCode(65 + i)}`,
        result: caseResults[Math.floor(sRand(0, caseResults.length))],
        amount: `${(sRand(1, 50)).toFixed(1)}万元`,
        date: `${2022 + Math.floor(sRand(0, 3))}-${String(Math.floor(sRand(1, 13))).padStart(2, '0')}-${String(Math.floor(sRand(1, 29))).padStart(2, '0')}`
      });
    }

    // 模块3: 司法判决
    const lawsuitTotal = Math.floor(sRand(5, 200));
    const lawsuitTypes = {
      '合同纠纷': Math.floor(sRand(5, 60)),
      '劳动争议': Math.floor(sRand(2, 40)),
      '知识产权': Math.floor(sRand(1, 30)),
      '不正当竞争': Math.floor(sRand(1, 20)),
      '侵权责任': Math.floor(sRand(1, 15)),
      '股权转让': Math.floor(sRand(0, 10))
    };
    const plaintiffRatio = +(sRand(0.3, 0.7)).toFixed(2);
    const defendantRatio = +(1 - plaintiffRatio).toFixed(2);

    const lawsuitCases = [];
    const lawsuitTypesArr = ['合同纠纷', '劳动争议', '知识产权', '不正当竞争', '侵权责任'];
    const courtResults = ['胜诉', '部分胜诉', '败诉', '调解'];
    for (let i = 0; i < Math.min(lawsuitTotal, 8); i++) {
      const isPlaintiff = sRand(0, 1) > 0.5;
      lawsuitCases.push({
        caseNo: `(${2022 + Math.floor(sRand(0, 3))})${String.fromCharCode(65 + Math.floor(sRand(0, 24)))}民初${Math.floor(sRand(1000, 9999))}号`,
        type: lawsuitTypesArr[Math.floor(sRand(0, lawsuitTypesArr.length))],
        role: isPlaintiff ? '原告' : '被告',
        opponent: `${['某某科技', '某某贸易', '某某投资', '某某传媒', '某某网络'][Math.floor(sRand(0, 5))]}有限公司`,
        result: courtResults[Math.floor(sRand(0, courtResults.length))],
        date: `${2022 + Math.floor(sRand(0, 3))}-${String(Math.floor(sRand(1, 13))).padStart(2, '0')}-${String(Math.floor(sRand(1, 29))).padStart(2, '0')}`
      });
    }

    // 模块4: 加班及员工评价
    const overtimeScore = {
      workIntensity: +(sRand(3, 10)).toFixed(1),
      overtimeFrequency: +(sRand(3, 10)).toFixed(1),
      weekendOvertime: +(sRand(2, 10)).toFixed(1),
      overtimeCompensation: +(sRand(2, 9)).toFixed(1),
      workLifeBalance: +(sRand(2, 8)).toFixed(1)
    };
    const satisfactionScore = +(sRand(2.5, 4.8)).toFixed(1);
    const satisfactionTotal = Math.floor(sRand(200, 5000));

    const positiveTags = ['扁平管理', '技术氛围好', '成长空间大', '福利待遇好', '团队氛围好', '弹性工作', '免费三餐', '股票期权', '培训体系完善', '领导nice'];
    const negativeTags = ['加班严重', '996文化', '管理混乱', '晋升困难', '薪资偏低', '压力太大', '频繁裁员', '流程繁琐', '部门墙高', '内卷严重'];
    const tagCloud = [];
    const tagCount = Math.floor(sRand(8, 16));
    for (let i = 0; i < tagCount; i++) {
      const isPositive = sRand(0, 1) > 0.4;
      const tags = isPositive ? positiveTags : negativeTags;
      tagCloud.push({
        text: tags[Math.floor(sRand(0, tags.length))],
        positive: isPositive,
        weight: Math.floor(sRand(50, 200))
      });
    }

    const reviews = [];
    const positiveReviews = [
      '公司技术栈很新，能学到很多东西，同事之间氛围融洽。',
      '福利待遇不错，有免费三餐和健身房，年终奖也比较丰厚。',
      '扁平化管理，领导比较随和，沟通成本低，工作效率高。',
      '公司对新人很友好，有完善的培训体系和导师制度。',
      '工作内容有挑战性，能接触到前沿技术，个人成长很快。'
    ];
    const negativeReviews = [
      '加班比较严重，尤其是项目上线期间，经常需要通宵。',
      '晋升通道不够清晰，需要熬资历，年轻人机会不多。',
      '跨部门协作比较困难，流程繁琐，效率偏低。',
      '绩效考核压力较大，末位淘汰制度让人很有紧迫感。',
      '公司规模扩大后，管理有些混乱，决策链路变长。'
    ];
    for (let i = 0; i < 6; i++) {
      const isPositive = i < 3;
      const pool = isPositive ? positiveReviews : negativeReviews;
      reviews.push({
        text: pool[Math.floor(sRand(0, pool.length))],
        sentiment: isPositive ? 'positive' : 'negative',
        rating: isPositive ? +(sRand(4, 5)).toFixed(1) : +(sRand(1.5, 3.5)).toFixed(1),
        date: `${2023 + Math.floor(sRand(0, 2))}-${String(Math.floor(sRand(1, 13))).padStart(2, '0')}-${String(Math.floor(sRand(1, 29))).padStart(2, '0')}`,
        position: ['前端工程师', '后端工程师', '产品经理', 'UI设计师', '数据分析师', '运营专员'][Math.floor(sRand(0, 6))]
      });
    }

    // 模块5: BOSS直聘活跃度
    const jobCount = Math.floor(sRand(10, 500));
    const activityScore = +(sRand(40, 98)).toFixed(1);
    const jobTypes = {
      '技术开发': Math.floor(sRand(5, 100)),
      '产品设计': Math.floor(sRand(3, 50)),
      '运营推广': Math.floor(sRand(3, 40)),
      '市场销售': Math.floor(sRand(2, 30)),
      '职能支持': Math.floor(sRand(2, 20)),
      '数据分析': Math.floor(sRand(1, 15))
    };
    const recruitTrend = [];
    for (let i = 0; i < 6; i++) {
      recruitTrend.push(Math.floor(sRand(20, 200)));
    }

    // 模块6: 求职建议
    const overallScore = Math.floor(sRand(35, 95));
    const riskLevel = overallScore >= 75 ? '低' : overallScore >= 50 ? '中' : '高';
    const riskColor = overallScore >= 75 ? '#00d4ff' : overallScore >= 50 ? '#f0b90b' : '#ff4757';

    const advantages = [];
    const disadvants = [];
    const advPool = ['行业前景广阔', '技术实力强', '品牌知名度高', '薪酬竞争力强', '员工福利完善', '培训体系健全', '股权激励丰厚', '国际化视野', '创新能力强', '团队氛围好'];
    const disPool = ['加班强度大', '竞争压力大', '组织架构调整频繁', '部分部门管理混乱', '晋升周期较长', '绩效考核严格', '工作生活平衡差', '裁员风险', '内部政治', '流程效率低'];
    const advCount = Math.floor(sRand(2, 5));
    const disCount = Math.floor(sRand(2, 5));
    const usedAdv = new Set();
    const usedDis = new Set();
    for (let i = 0; i < advCount; i++) {
      let idx;
      do { idx = Math.floor(sRand(0, advPool.length)); } while (usedAdv.has(idx));
      usedAdv.add(idx);
      advantages.push(advPool[idx]);
    }
    for (let i = 0; i < disCount; i++) {
      let idx;
      do { idx = Math.floor(sRand(0, disPool.length)); } while (usedDis.has(idx));
      usedDis.add(idx);
      disadvants.push(disPool[idx]);
    }

    const suggestions = [
      '建议通过多种渠道了解目标部门的工作氛围和文化',
      '面试时可以询问直属领导的管理风格和团队协作方式',
      '关注公司近期的组织架构调整和战略方向变化',
      '了解目标岗位的绩效考核标准和晋升路径',
      '建议与在职或离职员工进行深入沟通，获取真实信息',
      '注意查看劳动合同中的竞业限制和保密条款',
      '了解公司的期权/股权激励政策和兑现条件'
    ];

    const checklist = [
      { item: '核实公司工商注册信息', checked: false },
      { item: '查询公司法律诉讼记录', checked: false },
      { item: '了解公司财务状况', checked: false },
      { item: '调查公司口碑和员工评价', checked: false },
      { item: '核实薪资水平和市场对比', checked: false },
      { item: '了解加班文化和工作强度', checked: false },
      { item: '确认社保公积金缴纳情况', checked: false },
      { item: '审查劳动合同条款', checked: false },
      { item: '了解公司发展前景和行业地位', checked: false },
      { item: '咨询行业内的专业人士', checked: false }
    ];

    // 模块7: 投资情况
    const investmentEvents = [];
    const rounds = ['天使轮', 'A轮', 'B轮', 'C轮', 'D轮', 'E轮', '战略投资', 'Pre-IPO', 'IPO'];
    const investors = ['红杉资本', '经纬创投', 'IDG资本', '高瓴资本', '软银愿景', '腾讯投资', '阿里巴巴', '淡马锡', 'DST Global', '老虎环球', '中金资本', '深创投', '招银国际', '博裕资本', '云锋基金'];
    const eventCount = Math.floor(sRand(3, 10));
    for (let i = 0; i < eventCount; i++) {
      const year = 2015 + Math.floor(sRand(0, 10));
      const month = Math.floor(sRand(1, 13));
      investmentEvents.push({
        date: `${year}-${String(month).padStart(2, '0')}`,
        round: rounds[Math.min(i, rounds.length - 1)],
        amount: `${['数百万', '数千万', '1亿', '2亿', '3亿', '5亿', '10亿', '15亿', '20亿', '50亿'][Math.floor(sRand(0, 10))]}${sRand(0, 1) > 0.5 ? '美元' : '人民币'}`,
        investors: [investors[Math.floor(sRand(0, investors.length))], investors[Math.floor(sRand(0, investors.length))]].filter((v, i, a) => a.indexOf(v) === i),
        valuation: `${(sRand(1, 500)).toFixed(0)}亿${sRand(0, 1) > 0.5 ? '美元' : '人民币'}`
      });
    }
    investmentEvents.sort((a, b) => a.date.localeCompare(b.date));

    const investRoundDist = {};
    investmentEvents.forEach(e => {
      investRoundDist[e.round] = (investRoundDist[e.round] || 0) + 1;
    });

    const portfolioCompanies = [];
    const pcNames = ['某某AI科技', '某某云计算', '某某机器人', '某某芯片', '某某新能源', '某某生物科技', '某某教育', '某某金融科技', '某某物流', '某某医疗健康'];
    for (let i = 0; i < Math.floor(sRand(3, 8)); i++) {
      portfolioCompanies.push({
        name: pcNames[Math.floor(sRand(0, pcNames.length))],
        industry: industries[Math.floor(sRand(0, industries.length))],
        investAmount: `${(sRand(1000, 50000)).toFixed(0)}万元`,
        shareRatio: `${(sRand(5, 30)).toFixed(1)}%`,
        status: ['已退出', '持有中', 'IPO中'][Math.floor(sRand(0, 3))]
      });
    }

    const externalInvestment = {
      totalAmount: `${(sRand(10, 300)).toFixed(0)}亿元`,
      investorCount: Math.floor(sRand(5, 30)),
      latestRound: rounds[Math.min(eventCount - 1, rounds.length - 1)],
      latestValuation: `${(sRand(50, 2000)).toFixed(0)}亿元`
    };

    // 模块8: 社保缴纳
    const socialInsuranceTrend = [];
    for (let i = 0; i < 5; i++) {
      socialInsuranceTrend.push(Math.floor(sRand(500, 100000)));
    }

    const socialInsuranceRatios = {
      '养老保险': +(sRand(85, 100)).toFixed(1),
      '医疗保险': +(sRand(88, 100)).toFixed(1),
      '失业保险': +(sRand(80, 98)).toFixed(1),
      '工伤保险': +(sRand(85, 100)).toFixed(1),
      '生育保险': +(sRand(82, 98)).toFixed(1),
      '住房公积金': +(sRand(70, 100)).toFixed(1)
    };

    const actualVsExpected = {
      actual: Math.floor(sRand(500, 100000)),
      expected: Math.floor(sRand(500, 120000)),
      ratio: +(sRand(0.75, 0.99)).toFixed(2)
    };

    const industryCompare = {
      companyName: name,
      pensionRate: +(sRand(85, 100)).toFixed(1),
      industryAvg: +(sRand(78, 92)).toFixed(1),
      industryTop: +(sRand(95, 100)).toFixed(1)
    };

    // 模块9: 股票投资
    const stockMarkets = [];
    if (sRand(0, 1) > 0.3) {
      stockMarkets.push({
        market: '港股',
        code: `${Math.floor(sRand(1, 9999))}.HK`,
        name: name + '（港股）',
        currentPrice: +(sRand(10, 500)).toFixed(2),
        change: +(sRand(-5, 5)).toFixed(2),
        marketCap: `${(sRand(100, 10000)).toFixed(0)}亿港元`
      });
    }
    if (sRand(0, 1) > 0.4) {
      stockMarkets.push({
        market: '美股',
        code: name.substring(0, 4).toUpperCase(),
        name: name + '（美股）',
        currentPrice: +(sRand(5, 300)).toFixed(2),
        change: +(sRand(-8, 8)).toFixed(2),
        marketCap: `${(sRand(50, 5000)).toFixed(0)}亿美元`
      });
    }
    if (sRand(0, 1) > 0.5) {
      stockMarkets.push({
        market: 'A股',
        code: `${Math.floor(sRand(600000, 605000))}.SH`,
        name: name + '（A股）',
        currentPrice: +(sRand(5, 200)).toFixed(2),
        change: +(sRand(-5, 5)).toFixed(2),
        marketCap: `${(sRand(100, 8000)).toFixed(0)}亿元人民币`
      });
    }

    const stockPriceTrend = [];
    let basePrice = sRand(20, 200);
    for (let i = 0; i < 12; i++) {
      basePrice *= (1 + (sRand(-0.1, 0.15)));
      stockPriceTrend.push(+basePrice.toFixed(2));
    }

    const stockFinancials = {
      pe: +(sRand(10, 80)).toFixed(1),
      pb: +(sRand(1, 15)).toFixed(1),
      eps: +(sRand(0.5, 20)).toFixed(2),
      dividendYield: +(sRand(0, 5)).toFixed(2),
      revenueGrowth: +(sRand(-10, 50)).toFixed(1),
      profitGrowth: +(sRand(-15, 60)).toFixed(1)
    };

    // 模块10: 企业文化
    const cultureScores = {
      innovation: +(sRand(5, 10)).toFixed(1),
      collaboration: +(sRand(5, 10)).toFixed(1),
      transparency: +(sRand(4, 9)).toFixed(1),
      employeeCare: +(sRand(4, 9)).toFixed(1),
      growthSpace: +(sRand(5, 10)).toFixed(1)
    };

    const cultureTags = [];
    const allCultureTags = ['开放包容', '结果导向', '数据驱动', '用户至上', '快速迭代', '拥抱变化', '追求卓越', '务实高效', '持续学习', '多元文化', '扁平管理', '自我驱动', '创新突破', '团队协作', '社会责任'];
    const cultureTagCount = Math.floor(sRand(6, 12));
    const usedCultureTags = new Set();
    for (let i = 0; i < cultureTagCount; i++) {
      let idx;
      do { idx = Math.floor(sRand(0, allCultureTags.length)); } while (usedCultureTags.has(idx));
      usedCultureTags.add(idx);
      cultureTags.push(allCultureTags[idx]);
    }

    const benefits = [
      '五险一金（全额缴纳）',
      '补充商业保险',
      '年度健康体检',
      '带薪年假（15-20天）',
      '弹性工作时间',
      '免费三餐/餐补',
      '健身房/运动补贴',
      '年终奖金（1-6个月）',
      '股票期权/限制性股票',
      '子女教育补贴',
      '租房补贴/人才公寓',
      '年度旅游/团建'
    ];

    const activities = [
      { type: '培训', name: '新员工入职训练营', frequency: '每月', desc: '为期一周的系统培训，涵盖企业文化、业务知识和技能提升' },
      { type: '培训', name: '技术分享会', frequency: '每周', desc: '内部技术交流，分享前沿技术和最佳实践' },
      { type: '活动', name: '黑客马拉松', frequency: '每季度', desc: '48小时创新挑战赛，鼓励跨部门协作创新' },
      { type: '活动', name: '户外团建', frequency: '每半年', desc: '户外拓展训练和团队建设活动' },
      { type: '培训', name: '领导力发展计划', frequency: '每年', desc: '针对管理层的领导力提升培训项目' },
      { type: '活动', name: '公益志愿者活动', frequency: '每月', desc: '组织员工参与社区公益和志愿服务' }
    ];

    return {
      basicInfo: {
        name,
        industry,
        city,
        legalPerson,
        status,
        registeredCapital: `${registeredCapital}${capitalUnit}`,
        establishDate,
        employeeCount,
        registeredAddress: `${city}市${['朝阳区', '海淀区', '南山区', '浦东新区', '余杭区', '天河区'][Math.floor(sRand(0, 6))]}${['科技园', '产业园', '创新中心', '商务中心', '软件园'][Math.floor(sRand(0, 5))]}${Math.floor(sRand(1, 30))}栋`
      },
      annualReport: {
        years,
        revenue,
        profit,
        financialIndicators,
        summary: annualReportSummary
      },
      arbitration: {
        total: arbitrationTotal,
        types: arbitrationTypes,
        trend: arbitrationTrend,
        trendYears: ['2022', '2023', '2024'],
        cases: arbitrationCases
      },
      lawsuit: {
        total: lawsuitTotal,
        types: lawsuitTypes,
        plaintiffRatio,
        defendantRatio,
        cases: lawsuitCases
      },
      overtime: {
        scores: overtimeScore,
        satisfactionScore,
        satisfactionTotal,
        tagCloud,
        reviews
      },
      bossRecruit: {
        jobCount,
        activityScore,
        jobTypes,
        recruitTrend,
        recruitMonths: ['1月', '2月', '3月', '4月', '5月', '6月']
      },
      jobAdvice: {
        overallScore,
        riskLevel,
        riskColor,
        advantages,
        disadvantages: disadvants,
        suggestions,
        checklist
      },
      investment: {
        events: investmentEvents,
        roundDist: investRoundDist,
        portfolioCompanies,
        externalInvestment
      },
      socialInsurance: {
        trend: socialInsuranceTrend,
        trendYears: years,
        ratios: socialInsuranceRatios,
        actualVsExpected,
        industryCompare
      },
      stock: {
        markets: stockMarkets,
        priceTrend: stockPriceTrend,
        priceMonths: ['1月', '2月', '3月', '4月', '5月', '6月', '7月', '8月', '9月', '10月', '11月', '12月'],
        financials: stockFinancials
      },
      culture: {
        scores: cultureScores,
        tags: cultureTags,
        benefits,
        activities
      }
    };
  },

  _hashStr(str) {
    let hash = 0;
    for (let i = 0; i < str.length; i++) {
      const char = str.charCodeAt(i);
      hash = ((hash << 5) - hash) + char;
      hash |= 0;
    }
    return Math.abs(hash);
  }
};
