/**
 * Vercel Serverless Function 入口
 * 将 Vercel 的请求转发给原有的路由处理逻辑
 */

const { handleRequest } = require('../server/server');

module.exports = async function handler(req, res) {
  // 设置超时（Vercel Serverless 默认 10s）
  res.setTimeout(9000, () => {
    res.status(504).json({ code: 504, data: null, message: 'Gateway Timeout' });
  });

  // 将 Vercel 的 req/res 适配为 Node.js 原生格式
  const originalUrl = req.url || '';

  // 创建一个模拟的 Node.js 原生 req 对象
  const mockReq = {
    method: req.method,
    url: originalUrl,
    headers: req.headers || {}
  };

  // 创建一个模拟的 Node.js 原生 res 对象
  const mockRes = {
    statusCode: 200,
    headers: {},
    body: '',

    setHeader(name, value) {
      this.headers[name.toLowerCase()] = value;
    },

    writeHead(statusCode, headers) {
      this.statusCode = statusCode;
      if (headers) {
        Object.keys(headers).forEach(key => {
          this.headers[key.toLowerCase()] = headers[key];
        });
      }
    },

    end(data) {
      this.body = data || '';
      // 将模拟 res 的结果写入 Vercel 的 res
      Object.keys(this.headers).forEach(key => {
        const value = this.headers[key];
        if (typeof value === 'string' || Array.isArray(value)) {
          res.setHeader(key, value);
        }
      });
      res.status(this.statusCode).send(this.body);
    }
  };

  try {
    await handleRequest(mockReq, mockRes);
  } catch (err) {
    console.error('Serverless Function Error:', err);
    if (!res.headersSent) {
      res.status(500).json({ code: 500, data: null, message: 'Internal Server Error' });
    }
  }
};
